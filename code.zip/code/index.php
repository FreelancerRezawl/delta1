<?php include 'menu.php'; ?>
<?php
$conn = mysqli_connect("localhost", "root", "", "delta_institute_of_technology");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$upload_file = null;
$success_msg = "";
$error_msg = "";

if (isset($_POST["submit"])) {
    // Handle file upload
    $upload_dir = "uploads/";
    $photo_name = basename($_FILES["Student_Photo"]["name"]);
    $upload_file = $upload_dir . $photo_name;

    if (!empty($photo_name)) {
        if (!move_uploaded_file($_FILES["Student_Photo"]["tmp_name"], $upload_file)) {
            $error_msg = "Error uploading photo.";
            $upload_file = null;
        }
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO students_admission (
      admission_name, cours_duration, id_number, session, 
      students_bangla_name, students_english_name, fathers_bangla_name, 
      fathers_english_name, mothers_bangla_name, mothers_english_name, 
      mailing_address, permanent_address, religion, gender, date_of_birth, 
      blood_group, nationality, national_id_number, phone_number, email_address, 
      student_photo, admission_date
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param(
      "ssssssssssssssssssssss",
      $_POST['Admission_Name'],
      $_POST['Cours_Duration'],
      $_POST['ID_Number'],
      $_POST['Session'],
      $_POST['Students_Bangla_Name'],
      $_POST['Students_English_Name'],
      $_POST['Fathers_Bangla_name'],
      $_POST['Fathers_English_name'],
      $_POST['Mothers_Bangla_name'],
      $_POST['Mothers_English_name'],
      $_POST['Mailing_Address'],
      $_POST['Permanent_Address'],
      $_POST['Religion'],
      $_POST['Gender'],
      $_POST['Date_of_Birth'],
      $_POST['Blood_Group'],
      $_POST['Nationality'],
      $_POST['National_ID_Number'],
      $_POST['Phone_Number'],
      $_POST['Email_Address'],
      $upload_file,
      $_POST['Admission_Date']
    );

    if ($stmt->execute()) {
        $success_msg = "Admission submitted successfully!";
    } else {
        $error_msg = "Error inserting record: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Student Admission</title>
  <link rel="stylesheet" href="css/delta.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js "></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js "></script>
  <script>
    $(function () {
      $(".datepicker").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'yy-mm-dd'
      });
    });
  </script>
</head>
<body>

  <section class="company_title">
    <marquee><h1>ডেলটা কম্পিউটার ট্রেনিং ইন্সটিটিউট</h1></marquee>
    <div class="delta"><h1>Delta Computer Training Institute </h1></div>
    <div class="bangabandhu"><h3>Kaliakoir Hi-Tech Park</h3></div>
    <div class="kaliakoir"><h4>Kaliakoir, Gazipur.</h4></div>
    <div class="asmission"><h2>Admission Form</h2></div>
  </section>

  <?php if ($success_msg): ?>
    <div style="color:green; text-align:center;"><?php echo $success_msg; ?></div>
  <?php elseif ($error_msg): ?>
    <div style="color:red; text-align:center;"><?php echo $error_msg; ?></div>
  <?php endif; ?>

  <section class="student_information">
    <form action="delta_a.php" method="POST" enctype="multipart/form-data">
      <div class="logo"><img src="Delta Computer Logo.png" alt="Logo" /></div>

      <!-- Application for Admission -->
      <div class="form-group">
        <label>Application for Admission in:</label>
        <select name="Admission_Name" required>
          <option value="">Select</option>
          <option value="Basic Office Application">কম্পিউটার অফিস এপ্লিকেশন</option>
          <option value="Responsive Web Design">ওয়েব ডিজাইন + আউটসোর্সিং / ফ্রিল্যান্সিং  </option>
          <option value="Digital Marketing">ডিজিটাল মার্কেটিং + আউটসোর্সিং / ফ্রিল্যান্সিং</option>
          <option value="Graphics Design">গ্রাফিক্স ডিজাইন অ্যান্ড মাল্টিমিডিয়া প্রোগ্রামিং + আউটসোর্সিং/ ফ্রিল্যান্সিং</option>
          <option value="Driving cum Auto Mechanics (Driving Training)">ড্রাইভিং কাম অটো মেকানিক্স (ড্রাইভিং প্রশিক্ষণ)</option>
          <option value="Others">Others</option>
        </select>
      </div>

      <!-- Duration -->
      <div class="form-group">
        <label>Duration:</label>
        <select name="Cours_Duration" required>
          <option value="">Select</option>
          <option value="1 Month">1 Month</option>
          <option value="3 Month">3 Month</option>
          <option value="6 Month">6 Month</option>
        </select>
      </div>

      <!-- ID Number -->
      <div class="form-group">
        <label>ID Number:</label>
        <input type="text" name="ID_Number" placeholder="আইডির নাম্বার">
      </div>

      <!-- Session -->
      <div class="form-group">
        <label>Session:</label>
        <input type="text" name="Session" placeholder="সেশন">
      </div>

      <!-- Student Name -->
      <div class="form-group">
        <label>Student Name (Bangla):</label>
        <input type="text" name="Students_Bangla_Name" placeholder="বাংলায় নাম">
      </div>
      <div class="form-group">
        <label>Student Name (English):</label>
        <input type="text" name="Students_English_Name" placeholder="ইংরেজীতে নাম">
      </div>

      <!-- Father's Name -->
      <div class="form-group">
        <label>Father's Name (Bangla):</label>
        <input type="text" name="Fathers_Bangla_name" placeholder="বাংলায় নাম">
      </div>
      <div class="form-group">
        <label>Father's Name (English):</label>
        <input type="text" name="Fathers_English_name" placeholder="ইংরেজীতে নাম">
      </div>

      <!-- Mother's Name -->
      <div class="form-group">
        <label>Mother's Name (Bangla):</label>
        <input type="text" name="Mothers_Bangla_name" placeholder="বাংলায় নাম">
      </div>
      <div class="form-group">
        <label>Mother's Name (English):</label>
        <input type="text" name="Mothers_English_name" placeholder="ইংরেজীতে নাম">
      </div>

      <!-- Mailing Address -->
      <div class="form-group">
        <label>Mailing Address:</label>
        <input type="text" name="Mailing_Address" placeholder="বর্তমান ঠিকানা">
      </div>

      <!-- Permanent Address -->
      <div class="form-group">
        <label>Permanent Address:</label>
        <input type="text" name="Permanent_Address" placeholder="স্থায়ী ঠিকানা">
      </div>

      <!-- Religion -->
      <div class="form-group">
        <label>Religion:</label>
        <select name="Religion" required>
          <option value="">Select</option>
          <option value="Islam">Islam</option>
          <option value="Hinduism">Hinduism</option>
          <option value="Christianity">Christianity</option>
          <option value="Buddhism">Buddhism</option>
          <option value="Others">Others</option>
        </select>
      </div>

      <!-- Gender -->
      <div class="form-group">
        <label>Gender:</label>
        <select name="Gender" required>
          <option value="">Select</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Others">Others</option>
        </select>
      </div>

      <!-- Date of Birth -->
      <div class="form-group">
        <label>Date of Birth:</label>
        <input type="text" name="Date_of_Birth" placeholder="জন্ম তারিখ" class="datepicker">
      </div>

      <!-- Blood Group -->
      <div class="form-group">
        <label>Blood Group:</label>
        <input type="text" name="Blood_Group" placeholder="রক্তের গ্রুপ">
      </div>

      <!-- Nationality -->
      <div class="form-group">
        <label>Nationality:</label>
        <input type="text" name="Nationality" placeholder="জাতীয়তা">
      </div>

      <!-- National ID -->
      <div class="form-group">
        <label>National ID:</label>
        <input type="text" name="National_ID_Number" placeholder="জাতীয় পরিচয় পত্রের নাম্বার">
      </div>

      <!-- Phone Number -->
      <div class="form-group">
        <label>Phone Number:</label>
        <input type="text" name="Phone_Number" placeholder="মোবাইল নাম্বার">
      </div>

      <!-- Email -->
      <div class="form-group">
        <label>Email:</label>
        <input type="email" name="Email_Address" placeholder="ইমেল আইডি">
      </div>

      <!-- Photo Upload -->
      <div class="form-group">
        <label>Photo Upload:</label>
        <input type="file" name="Student_Photo">
      </div>

      <!-- Admission Date -->
      <div class="form-group">
        <label>Date of Admission:</label>
        <input type="text" name="Admission_Date" class="datepicker">
      </div>

      <!-- Submit Button -->
      <div class="btn">
        <input type="submit" class="button" name="submit" value="Save">
      </div>
    </form>
  </section>

</body>
</html>