<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$conn = new mysqli("localhost", "root", "", "delta_institute_of_technology");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$student = null;

// Check if an ID is passed
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Fetch student data
    $stmt = $conn->prepare("SELECT * FROM students_admission WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
    } else {
        die("Student not found.");
    }
} else {
    die("Invalid request.");
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $students_english_name = $conn->real_escape_string($_POST['students_english_name']);
    $students_bangla_name = $conn->real_escape_string($_POST['students_bangla_name']);
    $fathers_english_name = $conn->real_escape_string($_POST['fathers_english_name']);
    $fathers_bangla_name = $conn->real_escape_string($_POST['fathers_bangla_name']);
    $mothers_english_name = $conn->real_escape_string($_POST['mothers_english_name']);
    $mothers_bangla_name = $conn->real_escape_string($_POST['mothers_bangla_name']);
    $phone_number = $conn->real_escape_string($_POST['phone_number']);
    $email_address = $conn->real_escape_string($_POST['email_address']);
    $admission_name = $conn->real_escape_string($_POST['admission_name']);
    $date_of_birth = $conn->real_escape_string($_POST['date_of_birth']);
    $admission_date = $conn->real_escape_string($_POST['admission_date']);

    // Optional: handle photo upload separately if needed

    // Update query
    $update_stmt = $conn->prepare("
        UPDATE students_admission SET
            students_english_name = ?,
            students_bangla_name = ?,
            fathers_english_name = ?,
            fathers_bangla_name = ?,
            mothers_english_name = ?,
            mothers_bangla_name = ?,
            phone_number = ?,
            email_address = ?,
            admission_name = ?,
            date_of_birth = ?,
            admission_date = ?
        WHERE id = ?
    ");

    $update_stmt->bind_param(
        "sssssssssssi",
        $students_english_name,
        $students_bangla_name,
        $fathers_english_name,
        $fathers_bangla_name,
        $mothers_english_name,
        $mothers_bangla_name,
        $phone_number,
        $email_address,
        $admission_name,
        $date_of_birth,
        $admission_date,
        $id
    );

    if ($update_stmt->execute()) {
        // Redirect to preview or search after successful update
        header("Location: student_preview.php?id=$id");
        exit();
    } else {
        echo "<div style='color:red; text-align:center;'>Error updating record: " . $conn->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Student</title>
    <style>
        body {
            font-family: Arial;
            background: #f9f9f9;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 {
            text-align: center;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="date"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            box-sizing: border-box;
        }

        button {
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        a.back-link {
            display: inline-block;
            margin-top: 15px;
            color: #007BFF;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Student Information</h2>

    <form method="post" action="">
        <label>Student Name (English):</label>
        <input type="text" name="students_english_name" value="<?= htmlspecialchars($student['students_english_name']) ?>" required>

        <label>Student Name (Bangla):</label>
        <input type="text" name="students_bangla_name" value="<?= htmlspecialchars($student['students_bangla_name']) ?>" required>

        <label>Father Name (English):</label>
        <input type="text" name="fathers_english_name" value="<?= htmlspecialchars($student['fathers_english_name']) ?>" required>

        <label>Father Name (Bangla):</label>
        <input type="text" name="fathers_bangla_name" value="<?= htmlspecialchars($student['fathers_bangla_name']) ?>" required>

        <label>Mother Name (English):</label>
        <input type="text" name="mothers_english_name" value="<?= htmlspecialchars($student['mothers_english_name']) ?>" required>

        <label>Mother Name (Bangla):</label>
        <input type="text" name="mothers_bangla_name" value="<?= htmlspecialchars($student['mothers_bangla_name']) ?>" required>

        <label>Phone Number:</label>
        <input type="text" name="phone_number" value="<?= htmlspecialchars($student['phone_number']) ?>" required>

        <label>Email Address:</label>
        <input type="email" name="email_address" value="<?= htmlspecialchars($student['email_address']) ?>">

        <label>Admission Course:</label>
        <input type="text" name="admission_name" value="<?= htmlspecialchars($student['admission_name']) ?>" required>

        <label>Date of Birth:</label>
        <input type="date" name="date_of_birth" value="<?= htmlspecialchars($student['date_of_birth']) ?>" required>

        <label>Admission Date:</label>
        <input type="date" name="admission_date" value="<?= htmlspecialchars($student['admission_date']) ?>" required>

        <button type="submit">Update Student</button>
    </form>

    <a href="student_preview.php?id=<?= $student['id'] ?>" class="back-link">← Back to Preview</a>
</div>

</body>
</html>