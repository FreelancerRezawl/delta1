<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "delta";

// Connect
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get values
$admission_date  = $_POST['admission_date'];
$id_number       = $_POST['id_number'];
$student_name    = $_POST['student_name'];
$fathers_name    = $_POST['fathers_name'];
$mothers_name    = $_POST['mothers_name'];
$admission_name  = $_POST['admission_name'];
$session         = $_POST['session'];
$month_name      = $_POST['month_name'];
$instalment      = $_POST['instalment'];
$amount_tk       = $_POST['amount_tk'];

// Image Upload
$img_name = '';
if (isset($_FILES['student_image']) && $_FILES['student_image']['error'] === 0) {
    $upload_dir = 'uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    $img_name = basename($_FILES['student_image']['name']);
    $target_file = $upload_dir . $img_name;
    move_uploaded_file($_FILES['student_image']['tmp_name'], $target_file);
}

// Insert query
$sql = "INSERT INTO delta_computer_money_receipt (
    Admission_Date, ID_Number, Students_Name, Fathers_Name, Mothers_Name,
    Admission_Name, Session, Month_Name, Instalment, Amount_Tk, Student_Image
) VALUES (
    '$admission_date', '$id_number', '$student_name', '$fathers_name', '$mothers_name',
    '$admission_name', '$session', '$month_name', '$instalment', '$amount_tk', '$img_name'
)";

if ($conn->query($sql) === TRUE) {
    echo "Data saved successfully!";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
