<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>ডেলটা ইনষ্টিটিউট অফ টেকনোলজি</title>
	<link type="text/css" rel="stylesheet" href="style.css"/>
	<link type="text/css" rel="stylesheet" href="css/flexslider.css"/>
	<link href="https://fonts.googleapis.com/css?family=Dancing+Script|Lobster" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
	<script src="js/jquery.flexslider-min.js"></script>
	<style>
	*{
	margin:0; padding:0;
}
.container {
	width: 1020px;
    background: yellow none repeat scroll 0 0;
    clear: both;
    height: 10px;
    margin: 0 auto;
}
.logo{
	float:left;
	width:17%;
	height:150px;
	background:blue;
}
.logo img{
	margin-top: 0px;
    margin-left: 0px;
    width: 180px;
    height: 151px;
}
.delta{
	color: Green;
	text-align: center;
	font-size:38px;
}
.bangabandhu{
	color: black;
	text-align: center;
	font-size:35px;
}
.kaliakoir{
	color: black;
	text-align: center;
	font-size:30px;
}
.contact{
	
	
}
.top-nav{
	width:100%;
	height:45px;
	background-color:#bbbbbb;
}
.top-nav ul{
	list-style:none; margin:0; padding:0;
}
.top-nav ul li{
	position:relative; float:left;
}
.top-nav ul li a{
	display:block;
	height:45px;
	text-decoration:none;
	padding:9px 8px 9px 8px;
	box-sizing:border-box;
	overflow:hidden;
	font-size:15px;
	color:#FFF;
}
.top-nav ul li a:hover{
	background-color:red; color:white;
}
.top-nav ul li ul{
	display:none; position:absolute; width:300px;
}
.top-nav ul li ul li{
	float:none;
}
.top-nav ul li ul li a{
	background:blue;
}
.top-nav ul li ul li a:hover{
	background:gray; color:black;
}
.top-nav ul li:hover ul{
	display:block;	
}
.top-nav ul li:hover ul ul{
	display:none;
}
.top-nav ul li ul li ul{
	position: absolute; left:100%; top:0;
}
.top-nav ul li ul li:hover ul{
	display:block;
}
.top-nav ul li ul li ul a{
	background:Red;
}
.top-nav ul li ul li ul a:hover{
	background:gray;
}
.container1{
	max-width:1020px;
	height:400px;
	padding:50px 0px;
	margin:0 auto;
	background:url("Image/777.jpg");
	background-size:cover;
	background-position:center center;
	background-attachment:fixed;
}
.content h1{
	text-align:center;
	font-size:30px;
	color: blue;
	padding-bottom:20px;
}
* {
    box-sizing: border-box;
}
.column {
    float: left;
    width: 25%;
    padding: 5px 5px;
	border:5px solid blue;
}
.column p{
	text-align: justify;
}
.column p:hover{
	background-color: red;
}
.column img{
	width:230px; height:215px;
	padding-left:5px; border:10px solid yellow;
}


/* Clearfix (clear floats) */
.row::after {
    content: "";
    clear: both;
    display: table;
}
.slider{
	width:230px; height:215px; padding-top:20px;
}
.slider ul li img{
	border:20px solid yellow;
}
	</style>
</head>
<script>
//Can also be used with $(document).ready()
$(window).load(function(){
 $('.flexslider').flexslider({
    animation:"slide"
	});
	});
</script>
<body >
	<section id="first-section">
		<div class="container">
		<div class="logo">
		<img src="delta.jpg">
		</div>
		<div class="delta">
	<h1><center>Delta Institute of Technology</center></h1>
	</div>
	<div class="bangabandhu">
	<h3><center>Bangabandhu Hi-Tech City</center></h3>
	</div>
	<div class="kaliakoir">
	<h4><center>Kaliakoir, Gazipur .</center></h4><br>
	</div>
		
		<div class="contact">
		<img src="Udyanlogo.JPG">
		</div>
		</div>
	</section>
	<section id="second-section">
	<div class="container">
	<div class="top-nav">
	<ul>
		<li><a href="Home.php">হোম ||</a></li>
		
		<li><a href="#">শিক্ষার্থীদের তথ্য ||</a>
		<ul>
			
			
			<li><a href="#" target="_blank">ডেলটা ইনষ্টিটিউট অফ টেকনোলজি বেতনের রশিদ</a>
			<ul>
				<li><a href="Delta_Money_Receipt.php" target="_blank">বেতনের এন্টি ফরম</a></li>
				<li><a href="Delta_Money_Receipt_Display.php" target="_blank">আইডি ও তারিখ অনুসারে রিপোর্ট</a></li>
			</ul>
			<li><a href="#" target="_blank">ডেলটা  কম্পিউটার ট্রেনিং ইন্সটিটিউট  বেতনের রশিদ</a>
			<ul>
				<li><a href="Delta_Computer_Training_Institute_Money_Receipt.php" target="_blank">বেতনের এন্টি ফরম</a></li>
				<li><a href="Delta_Computer_Training_Institute_Money_Receipt_Display.php" target="_blank">আইডি ও তারিখ অনুসারে রিপোর্ট</a></li>
			</ul>
			</li>
			<li><a href="#" target="_blank">প্রবেশ পত্র</a>
			<ul>
				<li><a href="admit_card.php" target="_blank">ছাত্র/ছাত্রীদের প্রবেশ পত্র এন্টি ফরম</a></li>
				<li><a href="admit_card_display.php" target="_blank">একজন ছাত্র-ছাত্রীর রিপোর্ট</a></li>
				
			</ul>
			</li>
			
		</ul>
		</li>
		<li><a href="#">কোর্স অনুসারে ||</a>
		<ul>
		<li><a href="#" target="_blank">কোর্স সমূহ</a>
			<ul>
				<li><a href="select.php" target="_blank">অফিস অ্যাপ্লিকেশন</a></li>
				<li><a href="select.php" target="_blank">রেসপন্সিভ ওয়েব ডিজাইন</a></li>
				<li><a href="select.php" target="_blank">ওয়েব ডেভেলপমেন্ট</a></li>
				<li><a href="select.php" target="_blank">ওয়ার্ডপ্রেস থিম কাস্টমাইজেশনে এন্ড ডেভেলপমেন্ট</a></li>
				<li><a href="select.php" target="_blank">গ্রাফিক্স ডিজাইন</a></li>
				<li><a href="select.php" target="_blank">ইংলিশ স্পোকেন</a></li>
				<li><a href="select.php" target="_blank">সফটওয়্যার ডেভেলপমেন্ট</a></li>
				
			</ul>
			</li>
			</ul>
		</li>
		<li><a href="#">কর্মকর্তাদের তথ্য ||</a>
			<ul>
				<li><a href="Cash_memu.php">পরিচালক</a>
				<ul>
					<li><a href="Cash_memu.php" target="_blank">পরিচালকের তথ্য</a></li>
					
				</ul>
				
				</li>
				<li><a href="#">কর্মকর্তাদের তালিকা</a>
				<ul>
					<li><a href="Cash_memu.php" target="_blank">মৌসুমি আক্তার</a></li>
					<li><a href="Student_Information_final.php" target="_blank">সানজিদা আক্তার সন্ধা</a></li>
					<li><a href="Evaporter.php" target="_blank">আশরাফুল ইসলাম জাহিদ</a></li>
					<li><a href="Liner.php" target="_blank">দেওয়ান জাহিদ</a></li>
					<li><a href="Compressor.php" target="_blank">আসাদুজ্জামান আসাদ</a></li>
				</ul>
				</li>
				<li><a href="#">শিক্ষকদের তথ্য</a>
				<ul>
					<li><a href="Cash_memu.php" target="_blank">সালাহউদ্দিন শিপলু</a></li>
					<li><a href="Student_Information_final.php" target="_blank">আশরাফুল ইসলাম জাহিদ</a></li>
					<li><a href="Evaporter.php" target="_blank">শরিফুল ইসলাম</a></li>
					<li><a href="Liner.php" target="_blank">শাহরিয়ার ইসলাম</a></li>
					<li><a href="Compressor.php" target="_blank">নুরনবী হোসেন</a></li>
				</ul></li>
			</ul>
		</li>
		<li><a href="#">যোগাযোগ ||</a></li>
		<li><a href="#">নোটিশ ||</a></li>
		<li><a href="#">লগ আউট</a></li>
		
	</ul>
	</div>
	</div>
	
	</section>
<section id="third-section">
	<div class="container1">
	<div class="content">
	<h1> ডেলটা ইনষ্টিটিউট অফ টেকনোলজি এর পরিচিতি </h1>
	</div>
<div class="row">
  <div class="column">
    <img src="Image/BTEB.JPG">
</div>
  <div class="column">
    <img src="Image/delta 1.jpg">
</div>
  <div class="column">
    <img src="Image/delta.jpg">
</div>
  <div class="column">
    <img src="Image/sic.jpg">
</div>
</div>
	</div>
	</section>
<section id=""slide_section">
<div class="container">
<div class="slider"><!--start slider-->
<!-- place somewhere in the <body> of your page -->
<div class="flexslider">
	<ul class="slides">
		<li>
			<img src="Image/sharif.jpg">
		</li>
		<li>
			<img src="Image/13448.jpg">
		</li><li>
			<img src="Image/13253.jpg">
		</li><li>
			<img src="Image/17448.jpg">
		</li>
		<li>
			<img src="Image/sujon.jpg">
		</li>
	</ul>
	</div>
   </div>
</div>
</section>
</body>
<footer>
</footer>


</html>