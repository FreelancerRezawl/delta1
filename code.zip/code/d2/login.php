<?php

include 'config.php';

?>
<?php
session_start();
//if($_SERVER['REQUEST_METHOD'] !="POST"){
	//header("Location: index.php");
	//}else{
		$email = $_POST['email'];
		$password = $_POST["password"];
		$query ="select * from user where email='$email' and password='$password'";
		
		$query_check = mysqli_query($con,$query);
		if(mysqli_num_rows($query_check)>0){
			$_SESSION['email'] = $email;
			$_SESSION['password'] =$password;
			
			header("Location:success.php");
		}else{
			die("Email or Password Wrong !!!");
	}
//}
?>