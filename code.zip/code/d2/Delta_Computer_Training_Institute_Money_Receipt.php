<?php
$conn=mysqli_connect("localhost","root","");
	mysqli_select_db($conn,"delta_computr_training_institute");
?>
<html>
<head>
<meta charset="utf-8">
<title>Money Receipt</title>
   <script src="js/js1.js"></script>
  <script src="js/js2.js"></script>
  <script>
  $( function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true
    });
  } );
  </script>
<style>
*{
	margin: 0px; padding: 0px;
}
.company_title{
	width:700px;
	height:37px;
	background-color:#2F4F4F;
	margin: 0 auto;
	border-radius: 8px;
	border: 3px solid blue;
}
.money_receipt{
	background-color: #00FF00;
    border: 3px solid blue;
    border-radius: 12px;
    height: 695px;
    margin: 10px auto 0;
    padding-top: 20px;
    text-align: center;
    width: 700px;
}
.company_title h1{
	color: white;
	text-align: center;
	font-size:30px;
}
.company_title h2{
	color: white;
	text-align: center;
	font-size:20px;
}
.company_title h3{
	color: white;
	text-align: center;
	font-size:20px;
}
.logo{
	width: 100px;
	height: 0px;
	margin-top: -15px;
	margin-left: 14px;
}
.delta{
	color: Green;
	text-align: center;
	font-size:20px;
}
.bangabandhu{
	color: black;
	text-align: center;
	font-size:25px;
}
.kaliakoir{
	color: black;
	text-align: center;
	font-size:25px;
}
.admission{
	color: red;
	text-align: center;
	font-size:40px;
	text-align:suttonyMJ;
}

.cours{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left: 17px;
	margin-left: 2px;
	margin-left:-31px;
	font-size: 25px;
	margin-left: -5px;
}
.cours1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 3px;
}
.month{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left: 17px;
	margin-left: 2px;
	margin-left:-31px;
	font-size: 25px;
	margin-left: -5px;
	margin-left: 67px;
}
.month1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 3px;
}
.instalment{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left: 17px;
	margin-left: 2px;
	margin-left:-31px;
	font-size: 25px;
	margin-left: -5px;
	margin-left: 24px;
}
.instalment1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 3px;
}
.id_number{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left: 17px;
	margin-left: 2px;
	margin-left:-31px;
	font-size: 25px;
	margin-left: 15px;
}
.id1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 150px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 3px;
}
.Session{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left: 17px;
	margin-left: 2px;
	margin-left:-31px;
	font-size: 25px;
	margin-left: 61px;
}
.Session1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 4px;
}
.students_name{
	padding-left: 10px;
    text-align: left;
	border-radius:10px;
	margin-top: 9px;
	font-size: 25px;
}
.s_name {
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 465px;
	height: 35px;
	padding-left: 7px;
	margin-left: 196px;
	margin-top: -30px;
	font-size: 16px;
	font-size: 16px;
}
.div1{
	margin-left: 178px;
	margin-top: -29px;
}
.fathers_name{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left:-31px;
	margin-top: 0px;
	font-size: 25px;
}
.f_name{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 465px;
	height: 35px;
	padding-left: 7px;
	margin-left: 193px;
	margin-top: -30px;
	font-size: 16px;
}
.div2{
	margin-left: 174px;
	margin-top: -29px;
}
.mothers_name{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left:-31px;
	margin-top: 0px;
	font-size: 25px;
}
.m_name{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 465px;
	height: 35px;
	padding-left: 7px;
	margin-left: 193px;
	margin-top: -30px;
	font-size: 16px;
}
.div3{
	margin-left: 175px;
	margin-top: -29px;
}
.amount{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left: 17px;
	margin-left: 2px;
	margin-left:-31px;
	font-size: 25px;
	margin-left: 52px;
}
.amount1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 276px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 4px;
}
.date{
	text-align: left;
	font-size: 25px;
	margin-top: -120px;
	margin-left: 82px;
	font-size: 25px;
	margin-left: 133px;
}
.datepicker{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 138px;
	height: 35px;
	padding-left: 7px;
	margin-top: 148px;
}
.btn {
    padding-top: 1px;
    background-color: Red;
    background-color: Rad;
    margin-top: 20px;
    padding-bottom: 13px;
	height: 55px;
}

.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: black;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  cursor: pointer;
}

.button {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
  margin-right: 4px;
}

</style>
<body>
<section class="company_title">
<marquee>
<h1>ডেলটা কম্পিউটার ট্রেনিং ইন্সটিটিউট </h1>
</marquee>
</section>


<section class="money_receipt">
<form action="Delta_Computer_Training_Institute_Money_Receipt.php" Method="POST" cnctype="multipart/form-data" class="form_area">
	<div class="logo">
	<img src="Delta Computer Logo.jpg" width="100px" height="100px" alt="ayub">
	</div>
	<div class="delta">
	<h1><center>Delta Computer Training Institute</center></h1>
	</div>
	<div class="bangabandhu">
	<h3><center>Bangabandhu Hi-Tech City</center></h3>
	</div>
	<div class="kaliakoir">
	<h4><center>Kaliakoir, Gazipur.</center></h4><br>
	</div>
	<div class="admission">
	<center>Money Receipt</center>
	</div>
	<div class="date">
	<b>Date :</b> <input class="datepicker" type="date" name="Admission_Date" placeholder="তারিখ">
	</div>
	<div class="id_number">
	<b>ID Number :</b> <input class="id1" type="text" name="ID_Number" placeholder="আইডি নাম্বার">
	</div>
	<div class="students_name">
	<b>Student᾿s Name   <div class="div1">:</div></b> <input class="s_name" type="text" name="Students_Name" placeholder="ছাত্র / ছাত্রীর নাম">
	</div>
	<div class="fathers_name">
	<b>Father᾿s Name <div class="div2">:</div></b> <input class="f_name" type="text" name="Fathers_Name" placeholder="পিতার নাম">
	</div>
	<div class="mothers_name">
	<b>Mother᾿s Name <div class="div3">:</div></b> <input class="m_name" type="text" name="Mothers_Name" placeholder="মাতার নাম">
	</div>
	<div class="cours">
	<b>Course Name :</b>

	<select class="cours1" name="Admission_Name"> <option value="1"> Select </option>
									<option value="Basic Office Application">Basic Office Application</option>
									<option value="Responsiv Web Design">Responsiv Web Design</option>
									<option value="Web Development">Web Development</option>
									<option value="Graphics Design">Graphics Design</option>
									<option value="PHP + Laravel">PHP + Laravel</option>
									<option value="Wordpress Theme Customization">Wordpress Theme Customization</option>
									<option value="Software Development">Software Development</option>
									<option value="English Spoken">English Spoken</option>
									<option value="Others">Others</option>
													
								</select>
								</div>

	<div class="Session">
	<b>Session :</b> <input class="Session1" type="text" name="Session" placeholder="সেশন">
	</div>
	<div class="month">
	<b>Month :</b>
	<select class="month1" name="Month_Name"> <option value="1"> Select </option>
													<option value="January">January</option>
													<option value="February">February</option>
													<option value="March">March</option>
													<option value="April">April</option>
													<option value="May">May</option>
													<option value="June">June</option>
													<option value="July">July</option>
													<option value="August">August</option>
													<option value="September">September</option>
													<option value="October">October</option>
													<option value="November">November</option>
													<option value="December">December</option>
													
											</select>
											</div>
	<div class="instalment">										
	<b>Instalment :</b>	
	<select class="instalment1" name="Instalment"> <option value="1"> Select </option>
													<option value="1st Payement">1st Payement</option>
													<option value="2nd Payement">2nd Payement</option>
													<option value="3rd Payement">3rd Payement</option>
													<option value="4th Payement">4th Payement</option>
													<option value="5th Payement">5th Payement</option>
													
													
											</select>
											</div>

	<div class="amount">
	<b>Amount :</b> <input class="amount1" type="text" name="Amount_Tk" placeholder="টাকার পরিমান">
	</div>
	<div class="btn">
	<input type="submit" class="button" name="submit" value="Save">
	
	</div>
</body>
</head>

</html>
<?php
if(isset($_POST["submit"]))
{
	mysqli_query($conn,"insert into delta_computer_money_receipt value ('$_POST[Admission_Date]','$_POST[ID_Number]','$_POST[Students_Name]','$_POST[Fathers_Name]','$_POST[Mothers_Name]','$_POST[Admission_Name]','$_POST[Session]','$_POST[Month_Name]','$_POST[Instalment]','$_POST[Amount_Tk]')");
}
?>