
<!Doctype html>
<html>
  </head>
  <section class="company_title">
<marquee>
<h1>ডেলটা ইনষ্টিটিউট অফ টেকনোলজি </h1>
</marquee>
</section>


<section class="money_receipt">
<table class="text" border="1">
	 <div class="logo">
	<img src="delta.jpg" width="50px" height="50px" alt="ayub">
	</div>
	<div class="delta">
	<h1><center>Delta Institute of Technology</center></h1>
	</div>
	<div class="bangabandhu">
	<h3><center>Bangabandhu Hi-Tech City</center></h3>
	</div>
	<div class="kaliakoir">
	<h4><center>Kaliakoir, Gazipur.</center></h4><br>
	</div>
	<div class="text_area" id="Print">
	<table class="text" border="1">
	<form action="Delta_Money_Receipt_Report.php" Method="POST" cnctype="multipart/form-data" class="form_area">
	<h1><center> </center></h1>
	<div class="id">
	<b>Student ID :</b><input class="id1" type="text" name="ID_Number" placeholder=" Student ID ">
	</div>
	<div class="btn">
	<input type="submit" class="bbbttt" name="Search" value="Search">
	</div>
	</div>
	</form>
	</table>
	
<style>
*{
	margin: 0px; padding: 0px;
}
.company_title{
	width:501px;
	height:37px;
	background-color:Green;
	margin: 0 auto;
	border-radius: 8px;
	border: 3px solid blue;
}
.money_receipt{
	background-color: Orange;
    border: 3px solid blue;
    border-radius: 12px;
    height: 251px;
    margin: 10px auto 0;
    padding-top: 20px;
    text-align: center;
    width: 501px;
}
.company_title h1{
	color: white;
	text-align: center;
	font-size:30px;
	text-align:suttonyMJ;
}
.company_title h2{
	color: white;
	text-align: center;
	font-size:20px;
}
.company_title h3{
	color: white;
	text-align: center;
	font-size:20px;
}
.logo{
	width: 100px;
	height: 0px;
	margin-top: -15px;
	margin-left: -17px;
}
.delta{
	color: Green;
	text-align: center;
	font-size:20px;
}
.bangabandhu{
	color: black;
	text-align: center;
	font-size:18px;
}
.kaliakoir{
	color: black;
	text-align: center;
	font-size:15px;
}
.bor{
	border-collapse: collapse;
	text-align: center;
	margin: 0 auto;
}

.tdd {
    border-collapse: collapse;
    margin: 0 729px 0 auto;
    text-align: center;
}
.text_area{
	text-align: center;
}
.flex-container {
  display: flex;
  width: 200px;
  align-items: flex-start;
}
.id{
	padding-left: 44px;
    padding-top: 10px;
    text-align: left;
	margin-left: 17px;
	margin-left: 2px;
	margin-left:-31px;
	font-size: 25px;
}
.id1{
	border: 2px;
	solid: black;
	border-radius: 7px;
	width: 253px;
	height: 35px;
	padding-left: 7px;
	font-size: 16px;
	margin-left: 10px;
}

</style>
</body>
</html>