<?php
$conn = mysqli_connect('localhost','root','','delta_institute_of_technology');
if ($conn) {
	if(isset($_POST['Search'])){
		$ID_Number=$_POST['ID_Number'];
		
		
				
		$sql= "select * from students_admission where ID_Number='$ID_Number'";
		$result = mysqli_query($conn, $sql);
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf8">
<title>ভর্তি ফরম</title>
  <div class="date_picker">
 <script>
  $( function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true,
	  dateFormat:"yy-mm-dd"
	  });
  } );
  </script>
  </div>
  <script>
  function printRoutine(){
		printDiv("print_area");
	}
	
	function printDiv(Print) {
     var printContents = document.getElementById(Print).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

    window.print();
	
	  
	document.body.innerHTML = originalContents;
	
	 
}
  </script>
<style>

*{
	margin:0px; padding:0px;
}
.main{
	width:900px; height:1480px;	background-color: white;margin: 0 auto;	border-radius: 8px;	border:10px solid blue;	margin-top: 10px;
}
.delta{
	font-size: 35px;
    font-weight: bold;
    color: green;
}
.bangabandhu{
	font-size: 30px;
}
.kaliakoir{
	font-size: 25px;
}
.image{
	margin-top: -80px;
    margin-left: 415px;
}
.photo{
	margin-top: -194px;
    margin-left: 760px;
}
.admission{
	font-size: 30px;
    font-weight: bold;
    color: red;
    border: 2px solid;
    width: 230px;
    margin-left: 335px;
}
.qrcode{
	margin-top: -68px;
    margin-bottom: 0px;
	margin-left: 5px;
}

.pic{
	margin-top: -8px;
}
.application{
	margin-top: 30px;
    margin-left: 5px;
    font-size: 15px;
}
.semicolon1{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.application1{
	margin-top: -25px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.duration{
	margin-top: -11px;
    margin-left: 580px;
    font-size: 16px;
}
.semicolon2{
	margin-top: -18px;
    margin-left: 75px;
    font-weight: bold;
}
.cours{
	margin-top: -25px;
    margin-left: 670px;
    font-size: 16px;
    font-weight: bold;
}
.id_number{
	margin-top: 30px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon3{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.id1{
	margin-top: -25px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.Session{
	 margin-top: -10px;
    font-size: 16px;
    margin-left: 580px;
}
.semicolon4{
	margin-top: -18px;
    margin-left: 75px;
    font-weight: bold;
}
.Session1{
	margin-top: -25px;
    margin-left: 670px;
    font-size: 16px;
    font-weight: bold;
}
.students_name{
	margin-top: 25px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon5{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.s_name {
	margin-top: -25px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.students_name1{
	margin-top: 25px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon6{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.english1{
	margin-top: -25px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.fathers_name{
	margin-top: 30px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon7{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.f_name {
	margin-top: -25px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.fathers_name1{
	margin-top: 5px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon8{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.english2{
	margin-top: -25px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.mothers_name{
	margin-top: 30px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon9{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.m_name {
	margin-top: -25px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.mothers_name1{
	margin-top: 25px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon10{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.english3{
	margin-top: -25px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.mailing_address{
	margin-top: 30px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon11{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.m_address {
	margin-top: -30px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.permanent_address{
	margin-top: 30px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon12{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.p_address {
	margin-top: -30px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.religion{
	margin-top: 30px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon13{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.religion1{
	margin-top: -25px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.gender{
	margin-top: -12px;
    margin-left: 360px;
    font-size: 16px;
}
.semicolon14{
	margin-top: -18px;
    margin-left: 72px;
    font-weight: bold;
}
.gender1{
	margin-top: -25px;
    margin-left: 450px;
    font-size: 16px;
    font-weight: bold;	
}
.d_birth{
	margin-top: -12px;
    margin-left: 570px;
    font-size: 16px;
}
.semicolon15{
	margin-top: -18px;
    margin-left: 112px;
    font-weight: bold;
}
.birth{
	margin-top: -25px;
    margin-left: 700px;
    font-size: 16px;
    font-weight: bold;	
}
.b_group{
	margin-top: 30px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon16{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.blood{
	margin-top: -25px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.nationality{
	margin-top: -10px;
    margin-left: 330px;
    font-size: 16px;
}
.semicolon17{
	margin-top: -18px;
    margin-left: 100px;
    font-weight: bold;
}
.nationality1{
	margin-top: -25px;
    margin-left: 450px;
    font-size: 16px;
    font-weight: bold;	
}
.national_id{
	margin-top: -17px;
    margin-left: 570px;
    font-size: 16px;
}
.semicolon18{
	margin-top: -18px;
    margin-left: 103px;
    font-weight: bold;
}
.n_id{
	margin-top: -25px;
    margin-left: 700px;
    font-size: 16px;
    font-weight: bold;
}
.mobile_number{
	margin-top: 30px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon19{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.m_number{
	margin-top: -25px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.email{
	margin-top: -12px;
    margin-left: 450px;
    font-size: 16px;
}
.semicolon20{
	margin-top: -18px;
    margin-left: 63px;
    font-weight: bold;
}
.e_phone{
	margin-top: -25px;
    margin-left: 530px;
    font-size: 16px;
    font-weight: bold;
}
.relation_datils{
	margin-top: 20px;
    margin-left: 5px;
    font-size: 16px;
    font-weight: bold;
}
.G_P_name{
    margin-top: 30px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon21{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.G_name{
	margin-top: -30px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.occupation{
	margin-top: -7px;
    margin-left: 590px;
    font-size: 16px;
}
.semicolon22{
	margin-top: -18px;
    margin-left: 100px;
    font-weight: bold;
}
.Occupation1{
	margin-top: -30px;
    margin-left: 710px;
    font-size: 16px;
    font-weight: bold;
}
.relation{
	margin-top: 30px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon23{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.Relation1{
	margin-top: -30px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.g_mobile_number{
    margin-top: -7px;
    margin-left: 450px;
    font-size: 16px;
}
.semicolon24{
	margin-top: -18px;
    margin-left: 180px;
    font-weight: bold;
}
.g_m_number{
	margin-top: -27px;
    margin-left: 645px;
    font-size: 16px;
    font-weight: bold;
}
.g_address{
	margin-top: 35px;
    margin-left: 5px;
    font-size: 16px;
}
.semicolon25{
	margin-top: -18px;
    margin-left: 193px;
    font-weight: bold;
}
.g_address1{
	margin-top: -30px;
    margin-left: 220px;
    font-size: 16px;
    font-weight: bold;
}
.accademic{
	margin-top: 20px;
    margin-left: 5px;
    font-size: 16px;
	font-weight: bold;
}
.examination{
	margin-top: 10px;
    margin-left: 5px;
    font-size: 16px;
    font-weight: bold;
    border: 2px solid;
    padding: 5px;
    width: 170px;
}
.e_name{
	margin-top: -2px;
	margin-left: 5px;
    font-size: 12px;
	border: 2px solid;
	font-weight: bold;
    padding: 5px;
    width: 170px;
}
.subject{
	margin-top: -59px;
    margin-left: 187px;
    font-size: 16px;
    font-weight: bold;
	border: 2px solid;
    padding: 5px;
    width: 170px;
}
.s_group{
	margin-top: -2px;
    margin-left: 187px;
    font-size: 12px;
    border: 2px solid;
	font-weight: bold;
    padding: 5px;
    width: 170px;
}
.board{
	margin-top: -59px;
    margin-left: 369px;
    font-size: 16px;
    font-weight: bold;
    border: 2px solid;
    padding: 5px;
    width: 120px;
}
.board1{
	margin-top: -2px;
    margin-left: 369px;
    font-size: 12px;
    border: 2px solid;
	font-weight: bold;
    padding: 5px;
    width: 120px;
}
.year{
	margin-top: -59px;
    margin-left: 501px;
    font-size: 16px;
    font-weight: bold;
    border: 2px solid;
    font-weight: bold;
    padding: 5px;
    width: 100px;
}
.year1{
	margin-top: -2px;
    margin-left: 501px;
    font-size: 12px;
    border: 2px solid;
	font-weight: bold;
    padding: 5px;
    width: 100px;
}
.exam{
	margin-top: -59px;
    margin-left: 613px;
    font-size: 16px;
    font-weight: bold;
    border: 2px solid;
    padding: 5px;
    width: 120px;
}
.exam1{
	margin-top: -2px;
    margin-left: 613px;
    font-size: 12px;
    border: 2px solid;
	font-weight: bold;
    padding: 5px;
    width: 120px;
}
.cgpa{
	margin-top: -59px;
    margin-left: 745px;
    font-size: 16px;
    font-weight: bold;
    border: 2px solid;
    padding: 5px;
    width: 110px;
}
.cgpa1{
	margin-top: -2px;
    margin-left: 745px;
    font-size: 12px;
    border: 2px solid;
	font-weight: bold;
    padding: 5px;
    width: 110px;
}
.S_Signature{
	margin-top: 60px;
    margin-left: 5px;
    font-size: 16px;
    font-weight: bold;
}
.S_date{
	margin-top: 20px;
    margin-left: 5px;
    font-size: 16px;
    font-weight: bold;
}
.S_Signature1{
	margin-top: -22px;
    margin-left: 5px;
    border: 1px solid;
    width: 170px;
}
.G_Signature{
	margin-top: 0px;
    margin-left: 700px;
	font-size: 16px;
    font-weight: bold;
}
.G_date{
	margin-top: -18px;
    margin-left: 700px;
	font-size: 16px;
    font-weight: bold;
}
.G_Signature1{
	margin-top: -22px;
    margin-left: 700px;
    border: 1px solid;
    width: 170px;
}
.অঙ্গীকার{
	margin-top: 20px;
    margin-left: 5px;
    font-size: 16px;
    font-weight: bold;
}
.information{
	margin-top: 5px;
    margin-left: 5px;
    font-size: 16px;
    text-align: justify;
	margin-right: 5px;
}
.reception{
	margin-top: 185px;
    margin-left: 50px;
	font-weight: bold;
}
.reception1{
	margin-top: -25px;
    margin-left: 5px;
	border: 2px solid;
    width: 170px;
}
.manager{
	margin-top: 2px;
    margin-left: 255px;
	font-weight: bold;
}
.manager1{
	margin-top: -24px;
    margin-left: 240px;
    border: 2px solid;
    width: 170px;
}
.teachers{
	margin-top: 2px;
    margin-left: 500px;
	font-weight: bold;	
}
.teachers1{
	margin-top: -24px;
    margin-left: 470px;
    border: 2px solid;
    width: 170px;
}
.director{
	margin-top: 2px;
    margin-left: 730px;
	font-weight: bold;
}
.director1{
	margin-top: -24px;
    margin-left: 710px;
    border: 2px solid;
    width: 170px;
}
.date{
	margin-top: -1220px;
    margin-left: 5px;
    font-size: 16px;
    font-weight: bold;
}
.datepicker{
	margin-top: -17px;
    margin-left: 125px;
    font-size: 16px;
}
.button{
	margin-top: 1200px;
    margin-left: 1000px;
}

</style>
</head>
<body>
	
	<section class="main">
	<div class="delta">
	<h1><center>Delta Institute of Technology</center></h1>
	</div>
	<div class="bangabandhu">
	<h3><center>Bangabandhu Hi-Tech City</center></h3>
	</div>
	<div class="kaliakoir">
	<h4><center>Kaliakoir, Gazipur.</center></h4>
	</div>
	<div class="qrcode">
	<img src="qrcode.png" style=" width:120px; height:150px;"  alt="Ayub">
	</div>
	<div class="image"><img src="delta.jpg" height="15%" width="15%" alt="Ayub">
	</div>
	<div class="admission">
	<center>Admission From</center>
	</div><br><br>
	
<?php		{
		while($row=mysqli_fetch_assoc($result))	
		{
?>			
	
		<section class=>
		<div class="photo">		
		<td ><img  class="pic" style='width:120px' 'height:150px' src="../../../delta/image/<?php echo $row['Student_Photo']; ?>"/></td></div><br>
		<div class="application"><th><?php echo ' 1. Application for Admission in <div class="semicolon1">:......................................................................................</div>' ?></th></div><div class="application1"><td><?php echo $row['Admission_Name']; ?></td></div>
		<div class="duration"><th><?php echo ' 2. Duration <div class="semicolon2">:............................................................</div>' ?></th></div><div class="cours"><td><?php echo $row['Cours_Duration']; ?></td></div>
		<div class="id_number"><th><?php echo ' 3. ID Number <div class="semicolon3">:......................................................................................</div>' ?></th></div><div class="id1"><td><?php echo $row['ID_Number']; ?></td></div>
		<div class="Session"><th><?php echo ' 4. Session <div class="semicolon4">:............................................................</div>' ?></th></div><div class="Session1"><td><?php echo $row['Session']; ?></td></div>
		<div class="students_name"><th><?php echo ' 5. Students Name Bangla <div class="semicolon5">:.............................................................................................................................................................................</div>' ?></th></div><div class="s_name"><td><?php echo $row['Students_Bangla_Name']; ?></td></div>
		<div class="students_name1"><th><?php echo ' Students Name English <div class="semicolon6">:.............................................................................................................................................................................</div>' ?></th></div><div class="english1"><td><?php echo $row['Students_English_Name']; ?></td></div>
		<div class="fathers_name"><th><?php echo ' 6. Father᾿s Name Bangla <div class="semicolon7">:.............................................................................................................................................................................</div>' ?></th></div><div class="f_name"><td><?php echo $row['Fathers_Bangla_name']; ?></td></div></br>
		<div class="fathers_name1"><th><?php echo ' Father᾿s Name English <div class="semicolon8">:.............................................................................................................................................................................</div>' ?></th></div><div class="english2"><td><?php echo $row['Fathers_English_name']; ?></td></div>
		<div class="mothers_name"><th><?php echo ' 7. Mother᾿s Name Bangla <div class="semicolon9">:.............................................................................................................................................................................</div>' ?></th></div><div class="m_name"><td><?php echo $row['Mothers_Bangla_name']; ?></td></div>
		<div class="mothers_name1"><th><?php echo ' Mother᾿s Name English <div class="semicolon10">:.............................................................................................................................................................................</div>' ?></th></div><div class="english3"><td><?php echo $row['Mothers_English_name']; ?></td></div>
		<div class="mailing_address"><th><?php echo ' 8. Mailing Address <div class="semicolon11">:.............................................................................................................................................................................</div>' ?></th></div><div class="m_address"><td><?php echo $row['Mailing_Address']; ?></td></div>
		<div class="permanent_address"><th><?php echo ' 9. Permanent Address <div class="semicolon12">:.............................................................................................................................................................................</div>' ?></th></div><div class="p_address"><td><?php echo $row['Permanent_Address']; ?></td></div>
		<div class="religion"><th><?php echo ' 10. Religion <div class="semicolon13">:...............................</div>' ?></th></div><div class="religion1"><td><?php echo $row['Religion']; ?></td></div>
		<div class="gender"><th><?php echo ' 11. Gender <div class="semicolon14">:.........................</div>' ?></th></div><div class="gender1"><td><?php echo $row['Gender']; ?></td></div>
		<div class="d_birth"><th><?php echo '  12. Date of Birth <div class="semicolon15">:.....................................................</div>' ?></th></div><div class="birth"><td><?php echo $row['Date_of_Birth']; ?></td></div>
		<div class="b_group"><th><?php echo '  13. Blood Group <div class="semicolon16">:.....................</div>' ?></th></div><div class="blood"><td><?php echo $row['Blood_Group']; ?></td></div>
		<div class="nationality"><th><?php echo '  14. Nationality <div class="semicolon17">:...........................</div>' ?></th></div><div class="nationality1"><td><?php echo $row['Nationality']; ?></td></div>
		<div class="national_id"><th><?php echo '  15. National ID <div class="semicolon18">:.......................................................</div>' ?></th></div><div class="n_id"><td><?php echo $row['National_ID_Number']; ?></td></div>
		<div class="mobile_number"><th><?php echo '  16. Phone Number <div class="semicolon19">:................................................</div>' ?></th></div><div class="m_number"><td><?php echo $row['Phone_Number']; ?></td></div>
		<div class="email"><th><?php echo '  17. E-mail <div class="semicolon20">:...............................................................................................</div>' ?></th></div><div class="e_phone"><td><?php echo $row['Email_Address']; ?></td></div>
		<div class="relation_datils">18. Name, Relation and Full Address With Telephone of person who will be paying your tuition fees and other fees :</div>
		<div class="G_P_name"><th><?php echo '  Guardian Name <div class="semicolon21">:.......................................................................................</div>' ?></th></div><div class="G_name"><td><?php echo $row['Guardian_Present_Name']; ?></td></div>
		<div class="occupation"><th><?php echo '  Occupation  <div class="semicolon22">:...................................................</div>' ?></th></div><div class="Occupation1"><td><?php echo $row['Occupation']; ?></td></div>
		<div class="relation"><th><?php echo '  Relation <div class="semicolon23">:...............................................</div>' ?></th></div><div class="Relation1"><td><?php echo $row['Relation']; ?></td></div>
		<div class="g_mobile_number"><th><?php echo ' Gurdian Phone Number <div class="semicolon24">:..................................................................</div>' ?></th></div><div class="g_m_number"><td><?php echo $row['Gurdian_Phone_Number']; ?></td></div>
		<div class="g_address"><th><?php echo ' Address <div class="semicolon25">:.............................................................................................................................................................................</div>' ?></th></div><div class="g_address1"><td><?php echo $row['Gurdian_Address']; ?></td></div>
		<div class="accademic">19. Academic Information (Please mention latest degree only) :</div>
		<div class="examination"><th><center><?php echo '  Examination Name' ?></center></th></div><div class="e_name"><td><center><?php echo $row['Examination_Name']; ?></center></td></div>
		<div class="subject"><th><center><?php echo '  Subject Group' ?></center></th></div><div class="s_group"><td><center><?php echo $row['Subject_Group']; ?></center></td></div>
		<div class="board"><th><center><?php echo '  Board' ?></center></th></div><div class="board1"><td><center><?php echo $row['Board']; ?></center></td></div>
		<div class="year"><th><center><?php echo '  Passing Year' ?></center></th></div><div class="year1"><td><center><?php echo $row['Passing_Year']; ?></center></td></div>
		<div class="exam"><th><center><?php echo '  Roll of Exam' ?></center></th></div><div class="exam1"><td><center><?php echo $row['Roll_Exam']; ?></center></td></div>
		<div class="cgpa"><th><center><?php echo '  Division/GPA' ?></center></th></div><div class="cgpa1"><td><center><?php echo $row['Division']; ?></center></td></div>
		<div class="S_Signature">Student Signature</div>
		<div class="S_Signature1"></div>
		<div class="G_Signature">Guardian Signature</div>
		<div class="G_Signature1"></div>
		<div class="S_date">Date :</div>
		<div class="G_date">Date :</div>
		<div class="অঙ্গীকার"> 20. আবেদনকারীর অঙ্গীকার নাম :-</div>
		<div class="information"><p>               এই মর্মে অঙ্গীকার করিতেছি যে, বেসিক ট্রেড ৩/৬ মাস মেয়াদী কম্পিউটার প্রশিক্ষণ কোর্সে ভর্তি হওয়ার সুযোগ পেলে অত্র শিক্ষা প্রতিষ্ঠান ও বাংলাদেশ কারিগরি শিক্ষা বোর্ড এর যাবতীয় নিয়ম কানুন মেনে চলিব এবং দেশের আইন পরিপন্থি কোন কাজে লিপ্ত হব না এবং ভর্তি ফি ......................... টাকা, কোর্স ফি ....................... টাকা, রেজিস্ট্রেশন ফি ...............................টাকা, পরীক্ষা কেন্দ্র ফি .......................টাকা এবং নির্দিষ্ট সময় সূচি মোতাবেক সর্বমোট ..................................... টাকা পরিশোধ করিব। রশিদ মূলে সকল প্রদত্ত ফি ফেরত দাবী করিব না।</p></div>
		<div class="reception">Reception</div>
		<div class="reception1"></div>
		<div class="manager">Manager (Accounts)</div>
		<div class="manager1"></div>
		<div class="teachers">Course Teacher</div>
		<div class="teachers1"></div>
		<div class="director">Managing Director</div>
		<div class="director1"></div>
		<div class="date"><th><?php echo ' Admission Date:' ?></th></div><div class="datepicker"><td><?php echo $row['Admission_Date']; ?></td></div>
		
<?php

	}
}
?>
<?php		
}else{
	echo "Not Connected";
}
?>

</section>
<div class="button">
	<button type="button" onclick="print()">Print</button></div>
</body>
</html>