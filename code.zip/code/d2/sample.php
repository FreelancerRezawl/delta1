<?php
$conn = mysqli_connect('localhost','root','','delta_money_receipt');
if ($conn) {
	if(isset($_POST['Search'])){
		$ID_Number=$_POST['ID_Number'];
		$sql= "select * from money_receipt where ID_Number='$ID_Number'";
		$result = mysqli_query($conn, $sql);
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf8">
<title>Money Receipt</title>
<link type="text/css" rel="stylesheet" href="style4.css"></link>
<link rel="stylesheet" href="css/css1.css">
  <link rel="stylesheet" href="resources/demos/style.css">
  <script src="js/js1.js"></script>
  <script src="js/js2.js"></script>
  
<script>
function printRoutine(){
		printDiv("print_area");
	}
	
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
    window.print();
	document.body.innerHTML = originalContents;
}
</script>
  <script>                        
  $( function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true,
	  dateFormat:"yy-mm-dd"
	  });
  } );
  </script>
<style>
*{
	margin:0px; padding:0px;
}
.main{
	width:1000px; height:200px;	background-color: white;margin: 0 auto;	border-radius: 8px;	border:10px solid white;
}
.print_area{
	border-radius: 8px;	border:10px solid white;
	width:100px;
	height:150px;
	text-align: center;
	margin: 0 auto;
	float:left;
}
.bor{
	border-collapse: collapse;
	text-align: center;
	margin:auto;
	font-size:10px;
}
.total{
	padding-right:-50px;
}
.small{
	font-size:12px;
}
.imges img{
	width:30px;
	height:30px;
	margin-left: 0px;
    margin-top: 2px;
}
.text{
	margin-top:-85px;
	font-size: 14px;
}
.qrcode{
	margin-top: -7px;
    margin-bottom: 0px;
	margin-left: 235px;
}
.A_Signature{
	margin-top: 223px;
    margin-left: 5px;
    font-size: 12px;
    font-weight: bold;
}
.D_Signature{
	margin-top: -18px;
    margin-left: 221px;
}
.signature{
	margin-top: -117px;
}
.signature1{
	margin-top: 1px;
    margin-left: 247px;
}
.button{
	margin-top: 270px;
    margin-left: 420px;
}
</style>
</head>
<body class="main">
<div id="print_area">
	<div class="imges">
		<img src="delta.jpg">
	</div>
	<div class="qrcode">
	<img src="qrcode.png" style=" width:50px; height:50px;"  alt="Ayub">
	</div>
	<div class="text">
	<h3><center>ডেলটা ইনষ্টিটিউট অফ টেকনোলজি<center></h3>
	<h6><center>বঙ্গবন্ধু হাই-টেক সিটি, কালিয়াকৈর, গাজীপুর।<center></h6>
	<h6><center>বেতন রশিদ<center></h6>
	<h6><center>মোবা: 01319-511008, 01319-511009<center></h6>
	</div>
	<div class="small">
	<center><?php	date_default_timezone_set('Asia/Dhaka');
		 $date=date("d-m-y    h:i:s A ");
		echo "তারিখ: $date";
	?></center>
	</div>
	<div class="text_area">
	<table class="bor" border="1">
			<tr>
				<th>আইডি নাম্বার</th>
				<th>তারিখ</th>
				<th>ছাত্র/ছাত্রীদের নাম</th>
				<th>কোর্সের নাম</th>
				<th>টাকা</th>
				
			</tr>
<?php
	if($sql!=""){
		
		$t=0;	
	while($row = mysqli_fetch_assoc($result)){
		$t+=$row["Amount_Tk"];
?>
	<tr>
		<td><?php echo $row['ID_Number']; ?></td>
		<td><?php echo $row['Admission_Date']; ?></td>
		<td style="width:32px;"><?php echo $row['Students_Name']; ?></td>
		<td><?php echo $row['Admission_Name']; ?></td>
		<td><?php echo $row['Amount_Tk']; ?></td>
			
	</tr>
	
			
<?php
	}
	?>
	<tr>
	<td class="total" colspan="4" style="text-align:right"> মোট </td>
	<td> <?php echo $t;?></td>
	</tr>
	
	
	
	<?php 
	
}
?>
	</table>
<?php		
}else{
	echo "Not Connected";
}

?>
</div>
</div>
<div class="A_Signature"><th><?php echo '  Accounts Manager ' ?></div>
		<div class="D_Signature"><th><?php echo '  Managing Director ' ?></div>
		
<div class="button">
 <input type="button" value="Print" onClick="printRoutine()"></button>
<style>


</style>

</body>
</html>