<?php
$conn = mysqli_connect('localhost','root','','delta_computr_training_institute');
if ($conn) {
	if(isset($_POST['Search'])){
		$ID_Number=$_POST['ID_Number'];
		$sql= "select * from delta_computer_money_receipt where ID_Number='$ID_Number'";
		$result = mysqli_query($conn, $sql);
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf8">
<title>Money Receipt</title>
<link type="text/css" rel="stylesheet" href="style4.css"></link>
<link rel="stylesheet" href="css/css1.css">
  <link rel="stylesheet" href="resources/demos/style.css">
  <script src="js/js1.js"></script>
  <script src="js/js2.js"></script>
  
<script>
function printRoutine(){
		printDiv("print_area");
	}
	
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
    window.print();
	document.body.innerHTML = originalContents;
}
</script>
  <script>                        
  $( function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true,
	  dateFormat:"yy-mm-dd"
	  });
  } );
  </script>
<style>
*{
	margin:0px; padding:0px;
}
.main{
	width:280px; height:800px;	
	background-color: white;
	margin: 0 auto;	
	border-radius: 8px;	border:10px solid white;
}
.print_area{
	border-radius: 8px;	border:10px solid white;
	width:150px;
	height:600px;
	text-align: center;
	margin: 0 auto;
	float:left;
}
.bor{
	border-collapse: collapse;
	text-align: center;
	margin:auto;
	font-size:10px;
}
.total{
	padding-right:-50px;
}
.small{
	font-size:12px;
}
.imges img {
    margin-top: -44px;
	margin-left: -4px;
}
.text{
	margin-top: 1px;
    font-size: 14px;
}
.qrcode{
	margin-top: -60px;
    margin-left: 230px;
}
.manager{
	margin-top: 50px;
    margin-left: 5px;
    font-size: 12px;
    font-weight: bold;
}
.director{
	margin-top: -18px;
    margin-left: 157px;
}
.director{
	margin-top: -16px;
    margin-left: 124px;
}
.image{
	margin-top: -68px;
    margin-left: 33px;
}
.signature1{
	margin-top: -50px;
    margin-left: 160px;
}
.button{
	margin-top: -20px;
    margin-left: 375px;
}
</style>
</head>

<body class="main">
<div id="print_area">
	
	<div class="text">
	<h3><center>ডেলটা  কম্পিউটার ট্রেনিং ইন্সটিটিউট<center></h3>
	<h6><center>বঙ্গবন্ধু হাই-টেক সিটি, কালিয়াকৈর, গাজীপুর।<center></h6>
	<h6><center>জমা রশিদ<center></h6>
	<h6><center>মোবা: 01319-511008, 01319-511009<center></h6>
	</div>
	<div class="imges">
		<img src="Delta Computer Logo.png" height="10%" width="20%">
	</div>
	<div class="qrcode">
	<img src="qrcode.png" height="60%" width="70%" >
	</div>
	<div class="small">
	<center><?php	date_default_timezone_set('Asia/Dhaka');
		 $date=date("d-m-y    h:i:s A ");
		echo "তারিখ: $date";
	?></center>
	</div>
	<div class="text_area">
	<table class="bor" border="1">
			<tr>
				<th>আইডি নাম্বার</th>
				<th>তারিখ</th>
				<th>ছাত্র/ছাত্রীদের নাম</th>
				<th>কোর্সের নাম</th>
				<th>টাকা</th>
				
			</tr>
<?php
	if($sql!=""){
		
		$t=0;	
	while($row = mysqli_fetch_assoc($result)){
		$t+=$row["Amount_Tk"];
?>
	<tr>
		<td><?php echo $row['ID_Number']; ?></td>
		<td><?php echo $row['Admission_Date']; ?></td>
		<td style="width:32px;"><?php echo $row['Students_Name']; ?></td>
		<td><?php echo $row['Admission_Name']; ?></td>
		<td><?php echo $row['Amount_Tk']; ?></td>
			
	</tr>
	
			
<?php
	}
	?>
	<tr>
	<td class="total" colspan="4" style="text-align:right"> মোট </td>
	<td> <?php echo $t;?></td>
	</tr>
	
	
	
	<?php 
	
}
?>
	</table>
	<div class="manager">Accounts Manager</div>
	<div class="image"><img src="signiture_1-removebg-preview.png" height="15%" width="30%" alt="Ayub">
<div class="director">Managing Director</div>
<div class="signature1"><img src="signiture-removebg-preview.png" height="50%" width="60%" alt="Ayub">
<?php		
}else{
	echo "Not Connected";
}

?>
</div>
</div>

				
<div class="button">
 <input type="button" value="Print" onClick="printRoutine()"></button>
<style>


</style>

</body>
</html>