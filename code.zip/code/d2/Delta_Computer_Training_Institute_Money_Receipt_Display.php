<?php
$conn = mysqli_connect("localhost", "root", "", "delta");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle search request
$results = [];
if (isset($_POST['Search'])) {
    $student_id = $_POST['ID_Number'];
    $subject = $_POST['Admission_Name'];

    // Build query dynamically
    $query = "SELECT * FROM delta_computer_money_receipt WHERE 1=1";
    
    if (!empty($student_id)) {
        $query .= " AND Student_ID LIKE '%" . mysqli_real_escape_string($conn, $student_id) . "%'";
    }
    if ($subject != "1") { // 'Select' is value 1
        $query .= " AND Course_Name = '" . mysqli_real_escape_string($conn, $subject) . "'";
    }

    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $results[] = $row;
        }
    } else {
        echo "<script>alert('No records found!');</script>";
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admission Display</title>
<link type="text/css" rel="stylesheet" href="style4.css">
<link rel="stylesheet" href="css/css1.css">
<link rel="stylesheet" href="resources/demos/style.css">
<script src="js/js1.js"></script>
<script src="js/js2.js"></script>

<script>
$(function() {
    $(".datepicker").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'y-m-d'
    });
});
</script>
</head>
<body>

<section class="company_title">
<marquee><h1>ডেলটা কম্পিউটার ট্রেনিং ইন্সটিটিউট </h1></marquee>
</section>

<section class="student_information">
<div class="logo">
<img src="Delta Computer Logo.jpg" width="50px" height="50px" alt="Logo">
</div>
<div class="delta"><h1><center>Delta Computer Training Institute</center></h1></div>
<div class="bangabandhu"><h3><center>Bangabandhu Hi-Tech City</center></h3></div>
<div class="kaliakoir"><h4><center>Kaliakoir, Gazipur.</center></h4></div>

<div class="text_area" id="Print">
<form action="" method="POST" enctype="multipart/form-data" class="form_area">
<h1><center>Search Records</center></h1>

<div class="id">
<b>Student ID :</b>
<input class="id1" type="text" name="ID_Number" placeholder="Student ID">
</div>

<div class="subject">
<b>Subject:</b>
<select class="subject1" name="Admission_Name">
    <option value="1">Select</option>
    <option value="Basic Office Application">Basic Office Application</option>
    <option value="Responsive Web Design">Responsive Web Design</option>
    <option value="Web Development">Web Development</option>
    <option value="Graphics Design">Graphics Design</option>
    <option value="PHP + Laravel">PHP + Laravel</option>
    <option value="Wordpress Theme Customization">Wordpress Theme Customization</option>
    <option value="Software Development">Software Development</option>
    <option value="English Spoken">English Spoken</option>
    <option value="Others">Others</option>
</select>
</div>

<br><br>
<div class="btn">
<input type="submit" class="bbbttt" name="Search" value="Search">
</div>
</form>

<!-- Display Results -->
<?php if (!empty($results)): ?>
<h2 style="color:green; text-align:center;">Search Results</h2>
<table border="1" class="bor" style="width:90%; margin:auto; border-collapse:collapse;">
<tr style="background-color:#f2f2f2;">
    <th>Receipt No</th>
    <th>Student ID</th>
    <th>Name</th>
    <th>Course</th>
    <th>Amount</th>
    <th>Date</th>
</tr>
<?php foreach ($results as $row): ?>
<tr>
    <td><?= htmlspecialchars($row['Receipt_No']) ?></td>
    <td><?= htmlspecialchars($row['Student_ID']) ?></td>
    <td><?= htmlspecialchars($row['Student_Name']) ?></td>
    <td><?= htmlspecialchars($row['Course_Name']) ?></td>
    <td><?= htmlspecialchars($row['Total_Amount']) ?></td>
    <td><?= htmlspecialchars($row['Date']) ?></td>
</tr>
<?php endforeach; ?>
</table>
<?php endif; ?>

</div>
</section>

<style>
/* Your existing CSS styles here */
</style>

</body>
</html>