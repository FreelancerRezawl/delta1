<?php
$conn = mysqli_connect('localhost','root','','web');
if ($conn) {
	if(isset($_POST['Search'])){
		$student_id=$_POST['student_id'];
		$form_date=$_POST['form_date'];
		$to_date=$_POST['to_date'];
				
		$sql= "select * from play where student_id='$student_id' Or ( date between '$form_date' and '$to_date') Order by date ASC";
		$result = mysqli_query($conn, $sql);
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf8">
<title>Salary_Reports</title>
<link type="text/css" rel="stylesheet" href="style4.css"></link>
<link rel="stylesheet" href="css/css1.css">
  <link rel="stylesheet" href="resources/demos/style.css">
  <script src="js/js1.js"></script>
  <script src="js/js2.js"></script>
  
<script>
function printRoutine(){
		printDiv("print_area");
	}
	
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
    window.print();
	document.body.innerHTML = originalContents;
}
</script>
  <script>                                                                                                                                                                                                                                                                                                                                                                                                                                                            
  $( function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true,
	  dateFormat:"yy-mm-dd"
	  });
  } );
  </script>
<style>
*{
	margin:0px; padding:0px;
}
.print_area{
	width:260px;
	height:200px;
	text-align: center;
	margin: 0 auto;
	float:left;
	
}
.bor{
	border-collapse: collapse;
	text-align: center;
	margin:auto;
	font-size:10px;
}
.total{
	padding-right:-50px;
}
.small{
	font-size:12px;
}
.imges img{
	width:30px;
	height:30px;
	margin-left:550px;
	margin-top:20px;
}
.text{
	margin-top:-50px;
}
</style>
</head>
<body class="main">
<div id="print_area">
	<div class="imges">
		<img src="Sharif.JPG">
	</div>
	<div class="text">
	<h3><center>উদয়ন মডেল স্কুল<center></h3>
	<h6><center>টেংগুরী, বিকেএসপি, আশুলিয়া, সাভার, ঢাকা<center></h6>
	<h6><center>বেতন রশিদ<center></h6>
	<h6><center>মোবা: ০১৮১৫-৫০৬৮৮৫, ০১৭৩৯-০৫৩২৩৯<center></h6>
	</div>
	<div class="small">
	<center><?php	date_default_timezone_set('Asia/Dhaka');
		 $date=date("d-m-y    h:i:s A ");
		echo "তারিখ: $date";
	?></center>
	</div>
	<div class="text_area">
	<table class="bor" border="1">
			<tr>
				<th>আইডি</th>
				<th>তারিখ</th>
				<th>ছাত্র/ছাত্রীর নাম</th>
				<th>বর্ণনা</th>
				<th>টাকা</th>
				
			</tr>
<?php
	if($sql!=""){
		
		$t=0;	
	while($row = mysqli_fetch_assoc($result)){
		$t+=$row['taka'];
		//for($i=1;$i<=6;$i++){
?>
	<tr>
		<td><?php echo $row['student_id']; ?></td>
		<td><?php echo $row['date']; ?></td>
		<td style="width:32px;"><?php echo $row['student_name']; ?></td>
		<td><?php echo $row['discription']; ?></td>
		<td><?php echo $row['taka']; ?></td>
		
		
	</tr>
	
			
<?php
	}
	?>
	<tr>
		<td class="total" colspan="4" style="text-align:right">মোট: </td>
		
		<td><?php echo $t; ?></td>
		<?php echo $num=$t;
		
		$ones = array(
		0 =>"ZERO",
		1 => "ONE",
		2 => "TWO",
		3 => "THREE",
		4 => "FOUR",
		5 => "FIVE",
		6 => "SIX",
		7 => "SEVEN",
		8 => "EIGHT",
		9 => "NINE",
		10 => "TEN",
		11 => "ELEVEN",
		12 => "TWELVE",
		13 => "THIRTEEN",
		14 => "FOURTEEN",
		15 => "FIFTEEN",
		16 => "SIXTEEN",
		17 => "SEVENTEEN",
		18 => "EIGHTEEN",
		19 => "NINETEEN",
		"014" => "FOURTEEN"
		);
		$tens = array( 
		0 => "ZERO",
		1 => "TEN",
		2 => "TWENTY",
		3 => "THIRTY", 
		4 => "FORTY", 
		5 => "FIFTY", 
		6 => "SIXTY", 
		7 => "SEVENTY", 
		8 => "EIGHTY", 
		9 => "NINETY" 
		); 
		$hundreds = array( 
		"HUNDRED", 
		"THOUSAND", 
		"MILLION", 
		"BILLION", 
		"TRILLION", 
		"QUARDRILLION" 
		); /*limit t quadrillion */
		$num = number_format($num,2,".",","); 
		$num_arr = explode(".",$num); 
		$wholenum = $num_arr[0]; 
		$decnum = $num_arr[1]; 
		$whole_arr = array_reverse(explode(",",$wholenum)); 
		krsort($whole_arr,1); 
		$rettxt = ""; 
		foreach($whole_arr as $key => $i){
			
		while(substr($i,0,1)=="0")
				$i=substr($i,1,5);
		if($i < 20){ 
		/* echo "getting:".$i; */
		$rettxt .= $i; 
		}elseif($i < 100){ 
		if(substr($i,0,1)!="0")  $rettxt .= $tens[substr($i,0,1)]; 
		if(substr($i,1,1)!="0") $rettxt .= " ".$ones[substr($i,1,1)]; 
		}else{ 
		if(substr($i,0,1)!="0") $rettxt .= $ones[substr($i,0,1)]." ".$hundreds[0]; 
		if(substr($i,1,1)!="0")$rettxt .= " ".$tens[substr($i,1,1)]; 
		if(substr($i,2,1)!="0")$rettxt .= " ".$ones[substr($i,2,1)]; 
		} 
		if($key > 0){ 
		$rettxt .= " ".$hundreds[$key]." "; 
		}
		} 
		if($decnum > 0){
		$rettxt .= " and ";
		if($decnum < 20){
		$rettxt .= $ones[$decnum];
		}elseif($decnum < 100){
		$rettxt .= $tens[substr($decnum,0,1)];
		$rettxt .= " ".$ones[substr($decnum,1,1)];
			}
		}
		?>
	</tr>
	
	<?php 
	
}
?>
	</table>
<?php		
}else{
	echo "Not Connected";
}

?>
</div>
</div>
 <input type="button" value="Print" onClick="printRoutine()"></button>
<style>


</style>

</body>
</html>