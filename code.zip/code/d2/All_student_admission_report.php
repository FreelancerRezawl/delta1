<?php
$conn = mysqli_connect('localhost','root','','delta_institute_of_technology');
if ($conn) {
	if(isset($_POST['Search'])){
		$IDnum=$_POST['IDnum'];
		$class=$_POST['class'];
		$form_date=$_POST['form_date'];
		$to_date=$_POST['to_date'];
				
		$sql= "select * from students_admission where IDnum='$IDnum' Or class='$class'Or( Date between '$form_date' and '$to_date') Order by Date ASC";
		$result = mysqli_query($conn, $sql);
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf8">
<title>ভর্তি ফরম</title>
<link type="text/css" rel="stylesheet" href="style4.css"></link>
<link rel="stylesheet" href="css/css1.css">
  <link rel="stylesheet" href="resources/demos/style.css">
  <script src="js/js1.js"></script>
  <script src="js/js2.js"></script>
 <script>
  $( function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true,
	  dateFormat:"yy-mm-dd"
	  });
  } );
  </script>
  <script>
  function printRoutine(){
		printDiv("print_area");
	}
	
	function printDiv(Print) {
     var printContents = document.getElementById(Print).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

    window.print();
	
	  
	document.body.innerHTML = originalContents;
	
	 
}
  </script>
<style>
*{
	margin:0px; padding:0px;
}
</style>
</head>
<body>
	<h1><center>উদয়ন মডেল স্কুল<center></h1>
	<h4><center>টেংগুরী, বি.কে.এস.পি, আশুলিয়া, সাভার, ঢাকা<center></h4>
	<h3><center>স্থাপিত : ২০০৯ ইং<center></h3>
	<div class="text_area">
	<button type="button" onclick="print()">P</button>

	<table class="bor" border="1" style="table-layout:fixed" width="3600px" height="100px">
			<tr>
				<th>আইডি নম্বর</th>
				<th>তারিখ</th>
				<th style="width:175px;">ছাত্র-ছাত্রীদের নাম ( বাংলায়) </th>
				<th style="width:200px;">ছাত্র-ছাত্রীদের নাম ( ইংরেজীতে) </th>
				<th style="width:175px;">পিতার নাম (বাংলায়)</th>
				<th style="width:175px;">পিতার নাম (ইংরেজীতে)</th>
				<th style="width:175px;">মাতার নাম (বাংলায়)</th>
				<th style="width:175px;">মাতার নাম (ইংরেজীতে)</th>
				<th style="width:175px;">অভিভাবকের নাম</th>
				<th style="width:175px;">মোবাইল নম্বর</th>
				<th>টাকার পরিমাণ</th>
				<th>আয়ের উৎস</th>
				<th>সেশন</th>
				<th>শ্রেণি</th>
				<th>রোল</th>
				<th>সেকশন</th>
				<th>জাতীয়তা</th>
				<th>ধর্ম</th>
				<th>রক্তের ধরণ</th>
				<th>দিন</th>
				<th>মাস</th>
				<th>বছর</th>
				<th>বয়স</th>
				<th>লিঙ্গ</th>
				<th style="width:190px;">জন্মতারিখ নং</th>
				<th style="width:300px;">বর্তমান ঠিকানা</th>
				<th style="width:300px;" >স্থায়ী ঠিকানা</th>
				<th>ছবি</th>
				</tr>

<?php		{
		while($row=mysqli_fetch_assoc($result))	
		{
?>
	<tr>
		<td><?php echo $row['IDnum']; ?></td>
		<td><?php echo $row['date']; ?></td>
		<td><?php echo $row['sbname']; ?></td>
		<td><?php echo $row['sename']; ?></td>
		<td><?php echo $row['fbname']; ?></td>
		<td><?php echo $row['fename']; ?></td>
		<td><?php echo $row['mbname']; ?></td>
		<td><?php echo $row['mename']; ?></td>
		<td><?php echo $row['coname']; ?></td>
		<td><?php echo $row['mobile']; ?></td>
		<td><?php echo $row['income']; ?></td>
		<td><?php echo $row['job']; ?></td>
		<td><?php echo $row['ayear']; ?></td>
		<td><?php echo $row['class']; ?></td>
		<td><?php echo $row['roll']; ?></td>
		<td><?php echo $row['sections']; ?></td>
		<td><?php echo $row['nationality']; ?></td>
		<td><?php echo $row['relagion']; ?></td>
		<td><?php echo $row['blood']; ?></td>
		<td><?php echo $row['day']; ?></td>
		<td><?php echo $row['month']; ?></td>
		<td><?php echo $row['year']; ?></td>
		<td><?php echo $row['old']; ?></td>
		<td><?php echo $row['gender']; ?></td>
		<td><?php echo $row['birthdayno']; ?></td>
		<td><?php echo $row['preadd']; ?></td>
		<td><?php echo $row['peradd']; ?></td>
		<td><img style='width:50px' 'height:60px' src="../../../walton/Image/<?php echo $row['image']; ?>"/></td>
		</tr>	
		
<?php

	}
}
?>
	</table>
	
<?php		
}else{
	echo "Not Connected";
}

?>
<style>
.bor{
	border-collapse: collapse;
	text-align: center;
	margin: 0 auto;
}

.tdd {
    border-collapse: collapse;
    margin: 0 719px 0 auto;
    text-align: center;
}
.text_area{
	text-align: center;
}
.flex-container {
  display: flex;
  width: 200px;
  align-items: flex-start;
}

</body>
</html>