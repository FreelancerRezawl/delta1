<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "delta";

// Connect to database
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_FILES['student_image']) && isset($_POST['id_number'])) {
    $id = $_POST['id_number']; // Should match existing record
    $fileName = basename($_FILES['student_image']['name']);
    $targetDir = "uploads/";
    $targetFile = $targetDir . $fileName;

    // Create uploads folder if not exists
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    if (move_uploaded_file($_FILES['student_image']['tmp_name'], $targetFile)) {
        // Save image name in database
        $sql = "UPDATE delta_computer_money_receipt SET Student_Image = '$fileName' WHERE ID_Number = '$id'";
        if ($conn->query($sql) === TRUE) {
            echo "Image uploaded and saved to database!";
        } else {
            echo "DB Error: " . $conn->error;
        }
    } else {
        echo "Upload failed!";
    }
} else {
    echo "No file or ID number.";
}

$conn->close();
?>
