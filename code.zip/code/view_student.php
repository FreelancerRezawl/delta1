<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$conn = new mysqli("localhost", "root", "", "delta_institute_of_technology");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$student = null;

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM students_admission WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
    } else {
        die("Student not found.");
    }
} else {
    die("Invalid request.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Preview</title>
    <style>
        body {
            font-family: Arial;
            background: #f9f9f9;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 {
            text-align: center;
        }

        .info-group {
            margin-bottom: 15px;
        }

        label {
            font-weight: bold;
            display: block;
        }

        .photo {
            margin-top: 15px;
        }

        .photo img {
            max-width: 150px;
            border-radius: 6px;
        }

        a.back-link {
            display: inline-block;
            margin-top: 20px;
            color: #007BFF;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Student Preview</h2>

    <div class="info-group">
        <label>Student Name (English):</label>
        <p><?= htmlspecialchars($student['students_english_name']) ?></p>
    </div>

    <div class="info-group">
        <label>Student Name (Bangla):</label>
        <p><?= htmlspecialchars($student['students_bangla_name']) ?></p>
    </div>

    <div class="info-group">
        <label>Father Name:</label>
        <p>
            <?= htmlspecialchars($student['fathers_english_name']) ?> 
            (<?= htmlspecialchars($student['fathers_bangla_name']) ?>)
        </p>
    </div>

    <div class="info-group">
        <label>Mother Name:</label>
        <p>
            <?= htmlspecialchars($student['mothers_english_name']) ?> 
            (<?= htmlspecialchars($student['mothers_bangla_name']) ?>)
        </p>
    </div>

    <div class="info-group">
        <label>Phone:</label>
        <p><?= htmlspecialchars($student['phone_number']) ?></p>
    </div>

    <div class="info-group">
        <label>Email:</label>
        <p><?= htmlspecialchars($student['email_address']) ?></p>
    </div>

    <div class="info-group">
        <label>Admission Course:</label>
        <p><?= htmlspecialchars($student['admission_name']) ?></p>
    </div>

    <div class="info-group">
        <label>Date of Birth:</label>
        <p><?= htmlspecialchars($student['date_of_birth']) ?></p>
    </div>

    <div class="info-group">
        <label>Admission Date:</label>
        <p><?= htmlspecialchars($student['admission_date']) ?></p>
    </div>

    <div class="photo">
        <label>Photo:</label><br>
        <?php if (!empty($student['student_photo'])): ?>
            <img src="<?= htmlspecialchars($student['student_photo']) ?>" alt="Student Photo">
        <?php else: ?>
            No photo uploaded
        <?php endif; ?>
    </div>

    <a href="search_students.php" class="back-link">← Back to Search</a>
</div>

</body>
</html>