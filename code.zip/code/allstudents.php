<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "delta_institute_of_technology");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Query to fetch all data from the students_admission table
$sql = "SELECT * FROM students_admission";
$result = mysqli_query($conn, $sql);

// Function to format file size
function formatFileSize($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' bytes';
    }
}

// Check if there are any records
if (mysqli_num_rows($result) > 0) {
    echo "<table border='1' cellpadding='10' style='width:100%; border-collapse: collapse;'>";
    echo "<tr>
            <th>ID</th>
            <th>Admission Name</th>
            <th>Course Duration</th>
            <th>ID Number</th>
            <th>Session</th>
            <th>Student Bangla Name</th>
            <th>Student English Name</th>
            <th>Father's Bangla Name</th>
            <th>Father's English Name</th>
            <th>Mother's Bangla Name</th>
            <th>Mother's English Name</th>
            <th>Mailing Address</th>
            <th>Permanent Address</th>
            <th>Religion</th>
            <th>Gender</th>
            <th>Date of Birth</th>
            <th>Blood Group</th>
            <th>Nationality</th>
            <th>National ID Number</th>
            <th>Phone Number</th>
            <th>Email Address</th>
            <th>Student Photo</th>
            <th>Photo Size</th>
            <th>Admission Date</th>
          </tr>";

    // Output data of each row
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['admission_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['cours_duration']) . "</td>";
        echo "<td>" . htmlspecialchars($row['id_number']) . "</td>";
        echo "<td>" . htmlspecialchars($row['session']) . "</td>";
        echo "<td>" . htmlspecialchars($row['students_bangla_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['students_english_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['fathers_bangla_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['fathers_english_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['mothers_bangla_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['mothers_english_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['mailing_address']) . "</td>";
        echo "<td>" . htmlspecialchars($row['permanent_address']) . "</td>";
        echo "<td>" . htmlspecialchars($row['religion']) . "</td>";
        echo "<td>" . htmlspecialchars($row['gender']) . "</td>";
        echo "<td>" . htmlspecialchars($row['date_of_birth']) . "</td>";
        echo "<td>" . htmlspecialchars($row['blood_group']) . "</td>";
        echo "<td>" . htmlspecialchars($row['nationality']) . "</td>";
        echo "<td>" . htmlspecialchars($row['national_id_number']) . "</td>";
        echo "<td>" . htmlspecialchars($row['phone_number']) . "</td>";
        echo "<td>" . htmlspecialchars($row['email_address']) . "</td>";
        echo "<td><img src='" . htmlspecialchars($row['student_photo']) . "' alt='Student Photo' width='100'></td>";
        
        // Display file size
        $photoPath = htmlspecialchars($row['student_photo']);
        if (!empty($photoPath) && file_exists($photoPath)) {
            $fileSize = filesize($photoPath);
            echo "<td>" . formatFileSize($fileSize) . "</td>";
        } else {
            echo "<td>N/A</td>";
        }

        echo "<td>" . htmlspecialchars($row['admission_date']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='text-align:center;'>No records found.</p>";
}

// Close the connection
mysqli_close($conn);
?>