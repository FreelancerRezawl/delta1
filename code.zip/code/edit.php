<?php
session_start(); // Start session at the top

$host = "localhost";
$username = "root";
$password = "";
$database = "delta";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $conn->prepare("UPDATE delta_computer_money_receipt SET Admission_Date=?, Students_Name=?, Fathers_Name=?, Mothers_Name=?, Admission_Name=?, Session=?, Month_Name=?, Instalment=?, Amount_Tk=? WHERE ID_Number=?");
    $stmt->bind_param(
        "ssssssssss",
        $_POST['Admission_Date'],
        $_POST['Students_Name'],
        $_POST['Fathers_Name'],
        $_POST['Mothers_Name'],
        $_POST['Admission_Name'],
        $_POST['Session'],
        $_POST['Month_Name'],
        $_POST['Instalment'],
        $_POST['Amount_Tk'],
        $_POST['ID_Number']
    );
    $stmt->execute();

    // Save updated data into session
    $_SESSION['updated_data'] = $_POST;

    // Redirect to success page
    header("Location: update_success.php");
    exit;
}

$stmt = $conn->prepare("SELECT * FROM delta_computer_money_receipt WHERE ID_Number = ?");
$stmt->bind_param("s", $id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Record</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f7f9fc;
            margin: 0;
            padding: 30px;
        }
        .container {
            max-width: 600px;
            background-color: #fff;
            margin: auto;
            padding: 30px 40px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }
        label {
            font-weight: bold;
            display: block;
            margin-bottom: 6px;
            color: #333;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }
        input[type="submit"] {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }
        input[type="submit"]:hover {
            background-color: #218838;
        }
        .success-msg {
            text-align: center;
            margin-top: 30px;
            font-size: 18px;
            color: green;
        }
        a {
            color: #007bff;
            text-decoration: none;
            margin-left: 8px;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Student Record</h2>
    <form method="POST">
        <input type="hidden" name="ID_Number" value="<?php echo htmlspecialchars($data['ID_Number']); ?>">

        <label>Admission Date:</label>
        <input type="text" name="Admission_Date" value="<?php echo htmlspecialchars($data['Admission_Date']); ?>">

        <label>Student Name:</label>
        <input type="text" name="Students_Name" value="<?php echo htmlspecialchars($data['Students_Name']); ?>">

        <label>Father's Name:</label>
        <input type="text" name="Fathers_Name" value="<?php echo htmlspecialchars($data['Fathers_Name']); ?>">

        <label>Mother's Name:</label>
        <input type="text" name="Mothers_Name" value="<?php echo htmlspecialchars($data['Mothers_Name']); ?>">

        <label>Admission Name:</label>
        <input type="text" name="Admission_Name" value="<?php echo htmlspecialchars($data['Admission_Name']); ?>">

        <label>Session:</label>
        <input type="text" name="Session" value="<?php echo htmlspecialchars($data['Session']); ?>">

        <label>Month Name:</label>
        <input type="text" name="Month_Name" value="<?php echo htmlspecialchars($data['Month_Name']); ?>">

        <label>Installment:</label>
        <input type="text" name="Instalment" value="<?php echo htmlspecialchars($data['Instalment']); ?>">

        <label>Amount (Tk):</label>
        <input type="text" name="Amount_Tk" value="<?php echo htmlspecialchars($data['Amount_Tk']); ?>">

        <input type="submit" value="Update">
    </form>
</div>

</body>
</html>