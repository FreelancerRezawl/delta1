<?php include 'menu.php'; ?>
<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "delta";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM delta_computer_money_receipt";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Money Receipt</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 8px 12px;
            border: 1px solid #888;
            text-align: center;
        }
        th {
            background-color: #f3f3f3;
        }
        a.edit-btn {
            padding: 6px 10px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        a.edit-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<h2 style="text-align:center;">Student Money Receipt </h2>

<?php
if ($result->num_rows > 0) {
    echo "<table>
        <tr>
            <th>Admission Date</th>
            <th>ID Number</th>
            <th>Student Name</th>
            <th>Father's Name</th>
            <th>Mother's Name</th>
            <th>Admission Name</th>
            <th>Session</th>
            <th>Month</th>
            <th>Installment</th>
            <th>Amount (Tk)</th>
            <th>Action</th>
        </tr>";
    
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>{$row['Admission_Date']}</td>
            <td>{$row['ID_Number']}</td>
            <td>{$row['Students_Name']}</td>
            <td>{$row['Fathers_Name']}</td>
            <td>{$row['Mothers_Name']}</td>
            <td>{$row['Admission_Name']}</td>
            <td>{$row['Session']}</td>
            <td>{$row['Month_Name']}</td>
            <td>{$row['Instalment']}</td>
            <td>{$row['Amount_Tk']}</td>
            <td><a class='edit-btn' href='edit.php?id={$row['ID_Number']}'>Update</a></td>
        </tr>";
    }

    echo "</table>";
} else {
    echo "No data found.";
}

$conn->close();
?>

</body>
</html>
