<?php
session_start();

if (!isset($_SESSION['updated_data'])) {
    echo "<p>No updated data found.</p>";
    exit;
}

$data = $_SESSION['updated_data'];
unset($_SESSION['updated_data']); // Clear session after use
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Success</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f7f9fc;
            margin: 0;
            padding: 40px;
            text-align: center;
        }
        .receipt {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .logo {
            width: 80px;
            margin: 0 auto 20px auto;
            display: block;
        }
        h2 {
            color: #28a745;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        td,
        th {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        .print-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .print-btn:hover {
            background-color: #0056b3;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }

        /* Hide elements during printing */
        @media print {
            .no-print,
            .print-btn {
                display: none !important;
            }
            body * {
                visibility: hidden;
            }
            .receipt, .receipt * {
                visibility: visible;
            }
            .receipt {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                padding: 30px;
                box-shadow: none;
            }
        }
    </style>

    <!-- JavaScript for print -->
    <script>
        function printReceipt() {
            window.print();
        }
    </script>
</head>
<body>

<div class="receipt">
    <!-- Logo -->
    <img src="Delta Computer Logo.png" alt="Delta Computer Logo" class="logo">

    <h2>Update Complete — We're Grateful for Your Cooperation</h2>

    <table>
        <tr><th>Field</th><th>Value</th></tr>
        <tr><td>ID Number</td><td><?= htmlspecialchars($data['ID_Number']) ?></td></tr>
        <tr><td>Student Name</td><td><?= htmlspecialchars($data['Students_Name']) ?></td></tr>
        <tr><td>Admission Name</td><td><?= htmlspecialchars($data['Admission_Name']) ?></td></tr>
        <tr><td>Session</td><td><?= htmlspecialchars($data['Session']) ?></td></tr>
        <tr><td>Installment</td><td><?= htmlspecialchars($data['Instalment']) ?></td></tr>
        <tr><td>Amount (Tk)</td><td><?= htmlspecialchars($data['Amount_Tk']) ?></td></tr>
    </table>

    <!-- Print Button -->
    <button class="print-btn" onclick="printReceipt()">🖨️ Print Receipt</button>

    <br>
    <a href="index.php" class="no-print">Go To Home Page</a>
</div>

</body>
</html>