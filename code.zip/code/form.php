<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Student Data</title>
    <style>
        body {
            background: #f0f4f8;
            font-family: Arial, sans-serif;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-top: 30px;
        }

        form {
            width: 400px;
            margin: 30px auto;
            padding: 25px;
            background: #fff;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
        }

        input[type="text"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
            font-size: 14px;
        }

        button[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button[type="submit"]:hover {
            background-color: #2980b9;
        }

        label {
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Insert Student Information</h2>

<form action="save_form.php" method="post" enctype="multipart/form-data">
    <label>Admission Date:</label>
    <input type="text" name="admission_date" placeholder="YYYY-MM-DD" required>

    <label>ID Number:</label>
    <input type="text" name="id_number" required>

    <label>Student Name:</label>
    <input type="text" name="student_name" required>

    <label>Father's Name:</label>
    <input type="text" name="fathers_name">

    <label>Mother's Name:</label>
    <input type="text" name="mothers_name">

    <label>Admission Name:</label>
    <input type="text" name="admission_name">

    <label>Session:</label>
    <input type="text" name="session">

    <label>Month Name:</label>
    <input type="text" name="month_name">

    <label>Instalment:</label>
    <input type="text" name="instalment">

    <label>Amount Tk:</label>
    <input type="text" name="amount_tk">

    <label>Student Image:</label>
    <input type="file" name="student_image" accept="image/*">

    <button type="submit">Save Data</button>
</form>

</body>
</html>
