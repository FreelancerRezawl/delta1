-- Create database delta_money_receipt
CREATE DATABASE IF NOT EXISTS delta_money_receipt;
USE delta_money_receipt;

-- Create table money_receipt
CREATE TABLE IF NOT EXISTS money_receipt (
    Admission_Date DATE,
    ID_Number VARCHAR(50) NOT NULL,
    Students_Name VARCHAR(255),
    Fathers_Name VARCHAR(255),
    Mothers_Name VARCHAR(255),
    Admission_Name VARCHAR(255),
    Session VARCHAR(50),
    Month_Name VARCHAR(50),
    Instalment VARCHAR(50),
    Amount_Tk DECIMAL(10,2),
    PRIMARY KEY (ID_Number, Admission_Date)
);

-- Create database delta_institute_of_technology
CREATE DATABASE IF NOT EXISTS delta_institute_of_technology;
USE delta_institute_of_technology;

-- Create table students_admission
CREATE TABLE IF NOT EXISTS students_admission (
    Admission_Name VARCHAR(255),
    Cours_Duration VARCHAR(50),
    ID_Number VARCHAR(50) NOT NULL,
    Session VARCHAR(50),
    Students_Bangla_Name VARCHAR(255),
    Students_English_Name VARCHAR(255),
    Fathers_Bangla_name VARCHAR(255),
    Fathers_English_name VARCHAR(255),
    Mothers_Bangla_name VARCHAR(255),
    Mothers_English_name VARCHAR(255),
    Mailing_Address TEXT,
    Permanent_Address TEXT,
    Religion VARCHAR(50),
    Gender VARCHAR(50),
    Date_of_Birth DATE,
    Blood_Group VARCHAR(10),
    Nationality VARCHAR(100),
    National_ID_Number VARCHAR(50),
    Phone_Number VARCHAR(50),
    Email_Address VARCHAR(100),
    Examination_Name VARCHAR(100),
    Subject_Group VARCHAR(100),
    Board VARCHAR(100),
    Passing_Year YEAR,
    Roll_Exam VARCHAR(50),
    Division VARCHAR(50),
    Student_Photo VARCHAR(255),
    Admission_Date DATE,
    PRIMARY KEY (ID_Number)
);
