<!-- menu.php -->
<nav class="main-menu">
    <div class="menu-container">
        <!-- Logo Section -->
        <div class="logo">
            <img src="Delta Computer Logo.png" alt="Delta Institute Logo" >
        </div>

        <!-- Hamburger Toggle for Mobile -->
        <input type="checkbox" id="menu-toggle" />
        <label for="menu-toggle" class="hamburger">&#9776;</label>

        <!-- Menu Links -->
        <ul class="menu">
            <li><a href="index.php">Home</a></li>
            <li><a href="search_students.php">Search Student</a></li>
            <li><a href="money.php">Money Report</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
    </div>
</nav>

<style>
/* Reset & Base Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Sticky Menu */
.main-menu {
    position: sticky;
    top: 0;
    z-index: 1000;
    background-color: #003366;
    padding: 12px 0;
    font-family: Arial, sans-serif;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.menu-container {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
}

/* Logo Styles */
.logo {
    display: flex;
    align-items: center;
}

.logo img {
    max-height: 60px; /* Adjust this as needed */
    width: auto;
    max-width: 180px; /* Limit logo width if too big */
    object-fit: contain;
    margin-right: 15px;
}

/* Main Menu Styles */
.menu {
    list-style-type: none;
    display: flex;
    gap: 25px;
}

.menu li a {
    color: white;
    text-decoration: none;
    font-weight: bold;
    font-size: 1.2rem;
    padding: 10px 15px;
    transition: background 0.3s ease;
}

.menu li a:hover {
    background-color: rgba(255, 255, 255, 0.2);
    border-radius: 5px;
}

/* Hamburger Toggle */
.hamburger {
    display: none;
    font-size: 1.8rem;
    color: white;
    cursor: pointer;
}

#menu-toggle {
    display: none;
}

/* Responsive Design */
@media screen and (max-width: 768px) {
    .menu {
        position: absolute;
        top: 60px;
        left: 0;
        right: 0;
        background-color: #003366;
        flex-direction: column;
        display: none;
        padding: 10px 0;
    }

    .menu.active {
        display: flex;
    }

    .hamburger {
        display: block;
    }

    .logo img {
        max-height: 45px;
        max-width: 140px;
    }

    .menu li {
        width: 100%;
        text-align: center;
    }

    .menu li a {
        display: block;
        padding: 12px 0;
        font-size: 1.1rem;
    }
}
</style>

<script>
// Toggle mobile menu
document.querySelector('.hamburger')?.addEventListener('click', function () {
    document.querySelector('.menu')?.classList.toggle('active');
});
</script>