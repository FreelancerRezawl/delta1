<?php include 'menu.php'; ?>
<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$conn = new mysqli("localhost", "root", "", "delta_institute_of_technology");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$search_query = "";
$results = [];

if (isset($_GET['search'])) {
    $search_query = $conn->real_escape_string($_GET['search']);

    $sql = "
        SELECT * FROM students_admission
        WHERE 
            students_english_name LIKE '%$search_query%' OR
            students_bangla_name LIKE '%$search_query%' OR
            id_number LIKE '%$search_query%' OR
            phone_number LIKE '%$search_query%' OR
            email_address LIKE '%$search_query%'
        ORDER BY id DESC
    ";

    $result = $conn->query($sql);

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $results[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Search Students</title>
  <style>
    body { font-family: Arial; background: #f4f4f4; padding: 20px; }
    .container { max-width: 1200px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #ccc; }
    h2 { text-align: center; color: #333; }
    input[type="text"] {
      width: 100%;
      padding: 10px;
      font-size: 16px;
      margin-bottom: 20px;
      box-sizing: border-box;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    th, td {
      padding: 10px;
      border: 1px solid #ccc;
      text-align: left;
    }
    th {
      background-color: #007BFF;
      color: white;
    }
    img {
      max-width: 80px;
      border-radius: 4px;
    }
    .btn {
      padding: 5px 10px;
      text-decoration: none;
      color: white;
      border-radius: 4px;
      font-size: 14px;
    }
    .preview-btn { background-color: #28a745; }
    .edit-btn { background-color: #ffc107; color: black; }
  </style>
</head>
<body>

<div class="container">
  <h2>🔍 Search Student</h2>

  <form method="GET" action="">
    <input type="text" name="search" placeholder="Search by Name, ID, Phone or Email..." value="<?= htmlspecialchars($search_query) ?>">
  </form>

  <?php if (!empty($results)): ?>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Father</th>
          <th>Phone</th>
          <th>Email</th>
          <th>Photo</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($results as $student): ?>
          <tr>
            <td><?= htmlspecialchars($student['id_number']) ?></td>
            <td><?= htmlspecialchars($student['students_english_name']) ?><br><small><?= htmlspecialchars($student['students_bangla_name']) ?></small></td>
            <td><?= htmlspecialchars($student['fathers_english_name']) ?><br><small><?= htmlspecialchars($student['fathers_bangla_name']) ?></small></td>
            <td><?= htmlspecialchars($student['phone_number']) ?></td>
            <td><?= htmlspecialchars($student['email_address']) ?></td>
            <td>
              <?php if (!empty($student['student_photo'])): ?>
                <img src="<?= htmlspecialchars($student['student_photo']) ?>" alt="Photo">
              <?php else: ?>
                No photo
              <?php endif; ?>
            </td>
            <td>
              <a href="view_student.php?id=<?= $student['id'] ?>" class="btn preview-btn">Preview</a>
              <a href="edit_student.php?id=<?= $student['id'] ?>" class="btn edit-btn">Edit</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php elseif ($search_query != ""): ?>
    <p style="color:red;">No results found for "<strong><?= htmlspecialchars($search_query) ?></strong>".</p>
  <?php endif; ?>
</div>

</body>
</html>